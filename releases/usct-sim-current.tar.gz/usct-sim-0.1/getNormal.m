function n= getNormal(geometryVariable,coordSysType,layerNumber,elementNumber)

% Description: returns the coordinates of an element with layerNumber and elementNumber as stored in geometryVariable according to the coordSysType
% 
% Definitions:  2D_polar is a [alpha,rho,z] coordinate system
%               element is a template which can be respaceld by sender or receiver
%
% Input:    geometryVariable:   variable, which holds the information of a geometry type, initialize with function "initGeometryVariable"
%           coordSysType:       type of the coordinate system, at the moment 'cartesian' and '2D_polar' allowed
%           layerNumber:        number of the layer in which the element lies
%           elementNumber:      number of the element
%
% Output:  c:                   3D double coordinates
% 
% author: n.ruiter, adapted by izaak
% ersterstellungsdatum: 11.8.2004
% letzte aenderung: 11.8.2004
% probably does not make sence for polar coordinates

%All parameters available?
if (exist('geometryVariable')==0 | exist('coordSysType')==0 | exist('layerNumber') == 0 | exist('elementNumber')==0) 
    disp('CriticalError: Incomplete ParameterString');
    out = 0;
    return
end

% Simple test of plausability of the parameters
if (~(strcmp(coordSysType,'cartesian') | strcmp(coordSysType,'2D_polar')) | ~(strcmp(geometryVariable.coordinateSystemType,'cartesian') | strcmp(geometryVariable.coordinateSystemType,'2D_polar'))  | layerNumber <= 0 | elementNumber <= 0 | length(geometryVariable.normals(:,1,1))<layerNumber | length(geometryVariable.normals(1,:,1))<elementNumber)
    disp('CriticalError: Parameter(s) are not plausible ');
    out = 0;
    return
end


%get coordinates
n = geometryVariable.normals(layerNumber,elementNumber,:);
%Is a tranformation of the coordinate system necessary ?
if(~strcmp(coordSysType,geometryVariable.coordinateSystemType))
    if(geometryVariable.coordinateSystemType=='cartesian')
        [n(1),n(2)] = cart2pol(n(1),n(2));
    else
        [n(1),n(2)] = pol2cart(n(1),n(2));
    end
end

