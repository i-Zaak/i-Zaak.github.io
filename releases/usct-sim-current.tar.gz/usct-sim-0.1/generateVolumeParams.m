function [ volumeParams ] = generateVolumeParams( reducedColormap, colors, values )
assert(size(values,1)==size(reducedColormap,1) && size(reducedColormap,1)==size(colors,1), 'ERROR: number of colors, samples and values has to be same.')
assert(size(values,2)==3, 'ERROR: coefficients for attenuation, speed of sound and echogenity have to be specified.')

volumeParams = zeros(size(values,1), 3);
for i=1:size(colors,1)
  for j=1:size(reducedColormap,1)
    if colors(i) == reducedColormap(j)
      volumeParams(j,:) = values(i,:);
    end
  end
end


%function [ volumeParams ] = generateVolumeParams( slices, samples, reducedColormap, values )
%% Expects the values to be in same order as samples!
%% Samples: [x y slice] coordinates of a sample pixel of the subvolume.
%% The resulting params will be in same order as the colormap.
%
%assert(size(values,1)==size(reducedColormap,1) && size(reducedColormap,1)==size(samples,1), "ERROR: number of colors, samples and values has to be same.")
%assert(size(samples,2)==3, "ERROR: need to specify slice and coordinates for every sample."
%assert(size(values,2)==3, "ERROR: coefficients for attenuation, speed of sound and echogenity have to be specified.")

%volumeParams = zeros(size(values,1), 4);

%for i=1:size(samples,1)
%  color = slices(samples(1),samples(2),samples(3));
%  for j=1:size(reducedColormap,1)
%    if color == reducedColormap(j)
%      volumeParams(j,:) = values(i,:);
%    end
%  end
%end
