function varargout = UZV_zmena(varargin)

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @UZV_zmena_OpeningFcn, ...
                   'gui_OutputFcn',  @UZV_zmena_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before UZV_zmena is made visible.
function UZV_zmena_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to UZV_zmena (see VARARGIN)

% Choose default command line output for UZV_zmena
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes UZV_zmena wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = UZV_zmena_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in save_zmeny.
% "Save and Close"
function save_zmeny_Callback(hObject, eventdata, handles)
% hObject    handle to save_zmeny (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

nn1 = get(handles.nelinE,'string');nnN = str2num(nn1);
stred_frek1 = get (handles.stred_frekE,'string');str_f = str2num(stred_frek1);
vzork_frek1  = get (handles.vzork_frekE,'string');vz_f = str2num(vzork_frek1);
vz_spektrum1 = get(handles.vz_spektrumE,'string');vz_s = str2num(vz_spektrum1);
radius1 = get (handles.radiusE,'string');rad = str2num(radius1);
ztop1 = get (handles.ztopE,'string');top = str2num(ztop1);
zbottom1 = get (handles.zbottomE,'string');bottom = str2num(zbottom1);
sl_range = get (handles.sl_rangeE,'string');
rl_range = get (handles.rl_rangeE,'string');


if (vz_s>=32)&(vz_s<=512)&(nnN>=1)&(nnN<=2)&(str_f>=1)&(str_f<=20)...
        &(vz_f>=5)&(vz_f<=100)&(rad>=0.01)&(rad<=0.3)...
        &(top>=0)&(top<bottom)&(bottom<=0.163)
    
    h=get(handles.figure1,'userdata');
    
    set(h.text_betad,'string',nn1);
    set(h.stredni_frekvence,'string',stred_frek1);
    set(h.vzork_frekvence,'string',vzork_frek1);
    set(h.vz_spektrum,'string',vz_spektrum1);
    set(h.radius,'string',radius1);
    set(h.ztop,'string',ztop1);
    set(h.zbottom,'string',zbottom1);
    set(h.zbottom,'string',zbottom1);
    set(h.sl_rangeEE,'string',sl_range);
    set(h.rl_rangeEE,'string',rl_range);
    
    set(UZV_zmena,'visible','off');
else
    Error = errordlg('Some parameters are out of range.','Warning','modal');
    
end


% --- Executes during object creation, after setting all properties.
function stred_frekE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to stred_frekE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function stred_frekE_Callback(hObject, eventdata, handles)
% hObject    handle to stred_frekE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of stred_frekE as text
%        str2double(get(hObject,'String')) returns contents of stred_frekE as a double


% --- Executes during object creation, after setting all properties.
function vzork_frekE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vzork_frekE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function vzork_frekE_Callback(hObject, eventdata, handles)
% hObject    handle to vzork_frekE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vzork_frekE as text
%        str2double(get(hObject,'String')) returns contents of vzork_frekE as a double


% --- Executes during object creation, after setting all properties.
function vz_spektrumE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vz_spektrumE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function vz_spektrumE_Callback(hObject, eventdata, handles)
% hObject    handle to vz_spektrumE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vz_spektrumE as text
%        str2double(get(hObject,'String')) returns contents of vz_spektrumE as a double


% --- Executes during object creation, after setting all properties.
function radiusE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to radiusE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function radiusE_Callback(hObject, eventdata, handles)
% hObject    handle to radiusE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of radiusE as text
%        str2double(get(hObject,'String')) returns contents of radiusE as a double


% --- Executes during object creation, after setting all properties.
function pocet_pozicE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pocet_pozicE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function pocet_pozicE_Callback(hObject, eventdata, handles)
% hObject    handle to pocet_pozicE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pocet_pozicE as text
%        str2double(get(hObject,'String')) returns contents of pocet_pozicE as a double



function NelinE_Callback(hObject, eventdata, handles)
% hObject    handle to NelinE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of NelinE as text
%        str2double(get(hObject,'String')) returns contents of NelinE as a double


% --- Executes during object creation, after setting all properties.
function NelinE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to NelinE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double


% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





function ztopE_Callback(hObject, eventdata, handles)
% hObject    handle to ztopE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ztopE as text
%        str2double(get(hObject,'String')) returns contents of ztopE as a double





function sl_rangeE_Callback(hObject, eventdata, handles)
% hObject    handle to sl_rangeE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sl_rangeE as text
%        str2double(get(hObject,'String')) returns contents of sl_rangeE as a double


% --- Executes during object creation, after setting all properties.
function sl_rangeE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sl_rangeE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function rl_rangeE_Callback(hObject, eventdata, handles)
% hObject    handle to rl_rangeE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of rl_rangeE as text
%        str2double(get(hObject,'String')) returns contents of rl_rangeE as a double


% --- Executes during object creation, after setting all properties.
function rl_rangeE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rl_rangeE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


