% example runscript, place other in the runscripts folder

volumePath = '/storage/home/izaak/usct_simulation/phantoms/TUFFC_1';
resultsPath = '/scratch/izaak/exp_profile';
senderPath = '/storage/home/izaak/usct_simulation/geometries/kruhe_mk1/GeometryNormalsDiam0_18407_sender.mat';
receiverPath = '/storage/home/izaak/usct_simulation/geometries/kruhe_mk1/GeometryNormalsDiam0_18407_receiver.mat';
statsDataRoot = '/storage/home/izaak/usct_data/noise_amplitude_stats2/';
pathsFile = '/scratch/izaak/exp7/missing.txt';
cachePath = [resultsPath '/cache'];
reflectorsPath = resultsPath;
coordinatesPath = '';

mkdir(resultsPath);

senderLayers = [10 11]; %must be a vector of length 2 -- [firstLayer lastLayer]
receiverLayers = [1 47]; %same here

disp('Generating voxel model.')
% uncomment to generate voxelModel
volumePreprocess(volumePath);


volumeParams = load([volumePath '/slicesParams.mat']);
voxelModel = load([volumePath '/voxelModel.mat']);

disp('Generating parameters')
expParamsPath = generateExpParams(resultsPath);
expParamsPath = [resultsPath '/expParams.mat'];

disp('Preprocessing rays.')
profile on
coordinatesPaths = raysPreprocess( senderPath, receiverPath, expParamsPath, senderLayers, receiverLayers, statsDataRoot, resultsPath);
profile off
profsave(profile('info'),'rayProfile')
save([resultsPath '/coordinatesPaths.mat'], 'coordinatesPaths');
%load([resultsPath '/coordinatesPaths.mat'], 'coordinatesPaths');

disp('Generating scatterers.');

generateScatterers(1000, resultsPath, volumePath, resultsPath )
sc = load( [reflectorsPath '/scatterers.mat']);


%fid = fopen(pathsFile);
%line = fgetl(fid);
%coordinatesPaths=[];
%while ischar(line)
%    coordinatesPaths = [coordinatesPaths;line];
%    line = fgetl(fid);
%end
%fclose(fid);
disp('Processing rays. You can start the cache exchange now.')

%parfor i=1:size(coordinatesPaths,1)
%    c= load([coordinatesPaths(i,:) '/raysCoordinates.mat']);
%    coordinates =  c.coordinates;
%    processRays( expParamsPath, voxelModel, coordinates, sc.scatterers, coordinatesPaths(i,:), cachePath);
%end


disp('Done.')
