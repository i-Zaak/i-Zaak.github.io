function precomputeScatterer(coorNumber)

% example runscript, place other in the runscripts folder

volumePath = '/storage/home/izaak/usct_simulation/phantoms/TUFFC_1';
resultsPath = '/scratch/izaak/exp13';
senderPath = '/storage/home/izaak/usct_simulation/geometries/kruhe_mk1/GeometryNormalsDiam0_18407_sender.mat';
receiverPath = '/storage/home/izaak/usct_simulation/geometries/kruhe_mk1/GeometryNormalsDiam0_18407_receiver.mat';
statsDataRoot = '/storage/home/izaak/usct_data/noise_amplitude_stats2/';
pathsFile = '/scratch/izaak/exp7/missing.txt';
cachePath = '/scratch/izaak/exp13/cache';
reflectorsPath = resultsPath;
coordinatesPath = '';

volumeParams = load([volumePath '/slicesParams.mat']);
voxelModel = load([volumePath '/voxelModel.mat']);

expParamsPath = [resultsPath '/expParams.mat'];

load([resultsPath '/coordinatesPaths.mat'], 'coordinatesPaths');

sc = load( [reflectorsPath '/scatterers.mat']);
scatterers = sc.scatterers;

load([resultsPath '/allEmitters']);
coordSender = allCoords(coorNumber,:);
param = load(paramPath);
P0 = param.P;
radiationFunction = param.rad_fun;
a = param.a; %[m]
c = param.c;  % [m/s]
fs = param.fs;
N_spect = param.N_spect;

[extrem pixelSize] = computeExtrem(param.geometryEnvelope, voxelModel);


times = zeros(size(scatterers,1),1);
betads = zeros(size(scatterers,1),1);
pulses = zeros(size(scatterers,1),size(P0,1));
rayLengths = zeros(size(scatterers,1),1);
for j=1:size(scatterers,1)
    coordReflector = scatterers(j,1:3); % see generateScatterers
    PReflected = modifyPulse(P0, coordSender, coordReflector, senderNormal, radiationFunction,a , c, fs, N_spect); 
    [betad time rayLength] = simulate3DRay( voxelModel, pixelSize, coordSender, coordReflector, extrem);
    times(j) = time;
    betads(j) = betad;
    pulses(j,:) = PReflected;
    rayLengths(j) = rayLength;
end    
key = sprintf('o%06.0fo%06.0fo%06.0f', coordSender.*1000000);
save([resultsPath '/cache/' key], times betads pulses rayLengths)
