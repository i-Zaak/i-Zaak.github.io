%///////// Hlavn??? okno zobrazen??? //////////
function varargout = UZV(varargin)

addpath(cd());

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @UZV_OpeningFcn, ...
                   'gui_OutputFcn',  @UZV_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before UZV is made visible.
function UZV_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to UZV (see VARARGIN)

% Choose default command line output for UZV
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

puvodni = get(handles.text_uloz,'string');
if length(puvodni) < 1
    dirSave = cd ();
    set(handles.text_uloz,'string',dirSave);
end

% --- Outputs from this function are returned to the command line.
function varargout = UZV_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button "Simulation parameters" press.
function change_param_Callback(hObject, eventdata, handles)
% hObject    handle to change_param (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(UZV_zmena,'visible','on','userdata',handles);

% --- Executes on button press in start.
% "RUN Simulation"
function start_Callback(hObject, eventdata, handles)
% hObject    handle to start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Pocet_pozic = get(handles.pocet_pozic,'string');
nn = get(handles.text_betad,'string');
Stredni_frekvence = get(handles.stredni_frekvence,'string');
vzorkovaci_frekvence = get(handles.vzork_frekvence,'string');
vzorkovaci_spektrum = get(handles.vz_spektrum,'string');
radius = get(handles.radius,'string');
ztop = get(handles.ztop,'string');
zbottom = get(handles.zbottom,'string');
sl_range = get(handles.sl_rangeEE,'string');
rl_range = get(handles.rl_rangeEE,'string');

cesta_ulozeni = get(handles.text_uloz,'string');
%
h = handles; %get(0,'userdata');
Dir = get(h.edit_adr, 'String');
val = get(h.list_map,'Value');
str = get(h.list_map, 'String');
parametry_name = [Dir,'/parameters.mat'];
save(parametry_name);

%%  osetreni programu, zdali jsou nadefinovany mapy rychlosti a utlumu
set(0,'userdata',handles);
dir_zobr = get(handles.edit_adr,'string');

%FIXME mapa = double(imread([Dir,'\',str{val}]));
%FIXME map_vel_att_name = [Dir,'\',str{val},'.att_vel_scat.mat'];
map_vel_att_name = [Dir,'/','att_vel_scat.mat'];
D = dir([Dir,'/*.bmp']);
Names = {D.name};
[resolutionX resolutionY depth] = size(imread([Dir, '/', char(Names(1))]))
slices = zeros(resolutionX, resolutionY, length(Names));
for nameIndex=1:length(Names)   
    imageName = char(Names(nameIndex));
    mapa = imread([Dir,'/',imageName]);
    mapa = rgb2gray(mapa);
    slices(:,:,nameIndex) = mapa;
end

if (length(dir_zobr) < 3 )
    Error = errordlg('Map and tissue parameters not defined.','Warning','modal');
else
    try Cmap = load(map_vel_att_name); catch end
    if (exist ('Cmap'))
        Cvel = Cmap.map_vel;
        if min(min(Cvel))<1
           Error = errordlg('Mus??? b???t definov???ny rychlosti ?????????en???(v>0) v menu "Zobrazit mapu"','Varov???n???','modal'); 
        else            
            %uct_model3D
            step = 3;%155;
            % FIXME if file not exists then
            createModel=false
            if createModel
              voxelModel = generate3DFromSlices(slices, step, Cmap);
              save([Dir, '/voxelModel.mat'], 'voxelModel','-v7.3')
            else
              s = load([Dir, '/voxelModel.mat'],'voxelModel');
              voxelModel = s.voxelModel;
            end
            
            preprocess(handles,voxelModel);
            param = load([cesta_ulozeni '/expParam.mat']);
            dirsLayer = dir(cesta_ulozeni);
            for d=1:length(dirsLayer)
                if(dirsLayer(d).isdir && dirsLayer(d).name(1) ~= '.')
                    dirsNumber = dir([cesta_ulozeni '/' dirsLayer(d).name]);
                    for d2=1:length(dirsNumber)
                        if(dirsNumber(d2).isdir && dirsNumber(d2).name(1) ~= '.')                            
                            dataPath = [cesta_ulozeni '/' dirsLayer(d).name '/' dirsNumber(d2).name];
                            coo = load([dataPath '/raysCoordinates.mat'], 'coordinates');
                            coordinates = coo.coordinates;
                            processRays(param, voxelModel, coordinates, dataPath);
                        end
                    end
                end                
            end
            
            
        end
    
    end
end

% uct_model3D

%cd D:\VUT\Diplomka\Guide\
%cd D:\VUT\ultrazvuk
%uct_model3

%% --- Executes on button press in btn_closeWindow.
function btn_closeWindow_Callback(hObject, eventdata, handles)

% try delete(UZV_z); catch end
% try delete(UZV_zmena); catch end
% try delete(UZV); catch end
close all



% --- Executes during object creation, after setting all properties.
function list_map_CreateFcn(hObject, eventdata, handles)
% hObject    handle to list_map (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in list_map.
function list_map_Callback(hObject, eventdata, handles)
% hObject    handle to list_map (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns list_map contents as cell array
%        contents{get(hObject,'Value')} returns selected item from list_map



% --- Executes on button press in btn_zobrazeni.
% "Show Map"
function btn_zobrazeni_Callback(hObject, eventdata, handles)

dir_zobr = get(handles.edit_adr,'string');
if length(dir_zobr) < 3
    W = warndlg('Select map directory first.','Warning','modal');
    
else
    set(0,'userdata',handles);
    set(UZV_z,'visible','on'); 
end


% --- Executes on button press in btn_adr.
% "Map Directory"
function btn_adr_Callback(hObject, eventdata, handles)
% hObject    handle to btn_adr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
start_path = get(handles.edit_adr,'string');
try start_path = start_path{1}; catch end
directory_name = uigetdir(start_path,'Select Map Directory');

if length(directory_name) > 1
    set(handles.edit_adr,'string',directory_name);
    cd(directory_name);
end

%FIXME D = dir([directory_name,'\*.bmp']);
D = dir([directory_name,'/*.bmp']);
Names = {D.name};
set(handles.list_map,'string',Names);


% --- Executes during object creation, after setting all properties.
function edit_adr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_adr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

function edit_adr_Callback(hObject, eventdata, handles)


% --- Executes on button press in btn_cesta.
function btn_cesta_Callback(hObject, eventdata, handles)
% hObject    handle to btn_cesta (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

puvodni = get(handles.text_uloz,'string');
try puvodni = puvodni{1}; bd =1
catch end
dirSave = uigetdir(puvodni,'Select destination path for data');
if length(dirSave) > 1
    set(handles.text_uloz,'string',dirSave);
end


% --- Executes during object creation, after setting all properties.
function ztop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ztop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function zbottom_CreateFcn(hObject, eventdata, handles)
% hObject    handle to zbottom (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


