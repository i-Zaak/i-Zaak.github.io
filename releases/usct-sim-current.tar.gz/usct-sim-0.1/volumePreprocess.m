function [ greyScale] = volumePreprocess( slicesDir )

p = load([slicesDir,'/slicesParams.mat']);
%coordinates = p.coordinates;
velocities = double(p.velocities);
attenuations = double(p.attenuations);
echogenities = double(p.echogenities);
height = double(p.height);
width = double(p.width);
colors = p.colors;

D = dir([slicesDir,'/*.bmp']);
Names = {D.name};

[tmpImage rgbMap] = imread([slicesDir, '/', char(Names(1))]);
if(size(rgbMap))
    tmpImage = ind2gray(tmpImage, rgbMap);
else
    %tmpImage = rgb2gray(tmpImage);
    tmpImage = mean(tmpImage,3);
end
disp('warning check supressed on image data type!')
%tmpImage = im2uint8(tmpImage);
[resolutionX resolutionY] = size(tmpImage);
clear tmpImage;


assert(resolutionX ==resolutionY, 'ERROR: Slices have to be square.');

slices = zeros(resolutionX, resolutionY, length(Names));


for nameIndex=1:length(Names)
    imageName = char(Names(nameIndex));
    [image rgbMap2] = imread([slicesDir,'/',imageName]);
    assert( size(image,1) == size(image,2)  && size(image,2)== resolutionX, 'ERROR: all slices has to be of same size.');
    assert(isequal(rgbMap,rgbMap2), 'ERROR: All slices have to have the same colour map!');   

    if(size(rgbMap2))
        image = ind2gray(image, rgbMap2);
    else
        %image = rgb2gray(image);
        image = mean(image,3);
    end
    disp('warning check supressed on image data type!')
    %image = im2uint8(image);
    slices(:,:,nameIndex) = image;
end

reducedMap = unique(slices);
for i =1:length(reducedMap)
    slices(slices==reducedMap(i)) = i;
end
greyScale = (1:length(reducedMap))';

[ voxelMatrix ] = generate3DFromSlices2( slices, height, width );
values = [velocities attenuations echogenities];
[ volumeParams ] = generateVolumeParams( reducedMap, colors, values );

save([slicesDir, '/voxelModel.mat'], 'voxelMatrix', 'volumeParams','-v7.3')
end
