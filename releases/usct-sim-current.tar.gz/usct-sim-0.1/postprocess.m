paths='/tmp/paths.txt'
SNR = 11; % [dB]
fixData = 1;
addNoise = 0;


system('find /scratch/izaak/usct_workdir/exp33 -name data.mat | sed "s/data.mat//" > /tmp/paths.txt')
S = 0;
N = 0;
A = 0;

fid = fopen(paths);
line = fgetl(fid);

while ischar(line)
    load([line '/data']);
    if fixData
        load([line '/map']);
        save([line '/data'], 'AScans', 'Map');
    end
    line = fgetl(fid);
    N = N + size(AScans,1);
    A = A + size(AScans,2);
    S = S + sum(sum(AScans.^2));
end
fclose(fid);
S = S/N /A
Sn = S/(10^(SNR/10))

if addNoise
    fid = fopen(paths);
    line = fgetl(fid);
    while ischar(line)
        data = load([line '/data']);
        noise = randn(size(data.AScans)).* sqrt(Sn);
        data.AScans = data.AScans + int16(noise);
        save( [line '/data'], '-struct','data');
        line = fgetl(fid);
    end
end
