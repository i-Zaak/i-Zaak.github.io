function [extrem pixelSize] = computeExtrem(geometryEnvelope, voxelModel)
% the voxel space defined by voxelModel is scaled so that the
% sender/receiver coordinates closest to the axes are in the middle of the
% voxels on the surface of the voxel space. The space should have square
% base and be large enough in the Z dimension (square voxels are expected).
minX = geometryEnvelope(1,1);
maxX = geometryEnvelope(1,2);
minY = geometryEnvelope(2,1);
maxY = geometryEnvelope(2,2);
minZ = geometryEnvelope(3,1);
maxZ = geometryEnvelope(3,2);

m = max([maxX - minX maxY - minY]);
%squaredEnvelope = [minX minX + m;minY minY + m;minZ maxZ];

[vX vY vZ] = size(voxelModel.voxelMatrix);
assert(vX==vY, 'ERROR: square base expected')

pixelSize = m/(vX - 1);

extrem = zeros(3,2);
extrem(1,1)=minX - 0.5*pixelSize;
extrem(2,1)=minY - 0.5*pixelSize;
extrem(3,1)=minZ - 0.5*pixelSize;
extrem(1,2)=maxX + 0.5*pixelSize;
extrem(2,2)=maxY + 0.5*pixelSize;
extrem(3,2)=extrem(3,1) + vZ*pixelSize;
assert (extrem(3,2) >= maxZ+0.5*pixelSize, 'ERROR: the voxel model is too small in Z dimension')