savePath = '/scratch/izaak/usct_workdir/exp33'
load([savePath '/coordinatesPaths']);
step = 20;
for i=101:step:size(coordinatesPaths,1)
    i_end = i+step-1
    if i_end > size(coordinatesPaths,1)
        i_end = size(coordinatesPaths,1)
    end
    [status, result] = system( ['qsub -Wgroup_list=feec -q feec -l mem=2gb -l nodes=1:ppn=1 -l matlab=1 -v USCT_START=' int2str(i) ',USCT_STOP=' int2str(i_end) ' processMultiple.sh'])
    pause(0.1)
end
quit
