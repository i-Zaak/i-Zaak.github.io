#!/bin/bash
#module add matlab
cd /storage/home/izaak/usct_simulation
/software/matlab-7.12/bin/matlab -r "processMultiple($USCT_START, $USCT_STOP);quit"
