pathsFile = '/tmp/cachePaths';
resultPath = '/tmp/merged_cache.mat';
cachePath = '/scratch/izaak/exp13/cache'

% get new caches
fid = fopen(pathsFile);
line = fgetl(fid);
cachePaths={};
while ischar(line)
    cachePaths{end +1} = line;
    line = fgetl(fid);
end
fclose(fid);

%merge caches
for i=1:size(cachePaths,2)
    load(cachePaths{i});
    cache1 = cache;
    if ~exist([cachePath '/' key] ,'file')
        mergedCache = cache1;
    else
        load([cachePath '/' key]);
        mergedCache = cache;
        for i=1:size(cache1,1)
            if(cache1(i,1) > 0 || cache1(i,2) > 0 || cache1(i,3) > 0)
                mergedCache(i,:) = cache1(i,:);
            end
        end
    end

    cache = mergedCache;
    save([cachePath '/tmp_cache'], 'cache');
    system(['lockfile ' cachePath '/' key '.lock']);
    movefile([cachePath '/tmp_cache.mat'], [cachePath '/' key '.mat']);
    system(['rm -f ' cachePath '/' key '.lock']);
end

quit
