function [ ] = saveAScan( fname, AScan )
%save( [fname '_tmp'], 'AScan' );
%movefile([fname '_tmp.mat'],[fname '.mat'] );
system(['touch ' fname '.done']);  
end
