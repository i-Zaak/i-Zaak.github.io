savePath = '/storage/home/izaak/usct_workdir/exp16'
load([savePath '/allEmitters']);
for i=100:size(allCoords,1)
    [status, result] = system( ['qsub -Wgroup_list=feec -q feec -l mem=2gb -l nodes=1:ppn=1 -v USCT_COORNUM=' int2str(i) ' precomputeScatterers.sh'])
    pause(0.2)
end
quit
