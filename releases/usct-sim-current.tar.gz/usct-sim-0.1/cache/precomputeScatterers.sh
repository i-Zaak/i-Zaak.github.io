#!/bin/bash
module add matlab
cd /storage/home/izaak/usct_simulation
matlab -r "precomputeScatterers($USCT_COORNUM);quit"
