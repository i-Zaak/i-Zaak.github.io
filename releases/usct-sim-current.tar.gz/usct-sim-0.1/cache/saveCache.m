function [] = saveCache(key, cache, savePath, filename)
save([savePath '/tmp_cache'], 'cache','key');
movefile([savePath '/tmp_cache.mat'], [savePath '/' filename '.mat']);
