#!/bin/bash
DATAROOT=/scratch/izaak/exp13
PATHSFILE=/tmp/cachePaths
MATLAB=matlab
MERGEDPATH=/tmp/merged_cache.mat

find $DATAROOT -name "cache_*" | head -n 10000 > $PATHSFILE

$MATLAB -r mergeCache

for line in `cat $PATHSFILE`; do
  rm $line
  #path=`echo $line | sed 's/cache_.*//'`;
  #rm $path/cache_*
  #cp $MERGEDPATH $path;  
  #touch $path/load_cache
done
