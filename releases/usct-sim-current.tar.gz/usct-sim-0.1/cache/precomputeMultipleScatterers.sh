#!/bin/bash
module add matlab
cd /storage/home/izaak/usct_simulation
matlab -r "precomputeMultipleScatterers($USCT_START, $USCT_STOP);quit"
