#!/bin/bash

. constants.sh

find $DATAROOT -name "raysCoordinates.mat" > $PATHSFILE

for line in `cat $PATHSFILE`; do
  path=`echo $line | sed 's/raysCoordinates.mat//'`;
  touch $path/load_cache
done
