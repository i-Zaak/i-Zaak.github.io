#!/bin/bash
DATAROOT=/mnt/data/izaak/usct_simulated_data/exp10
PATHSFILE=/tmp/cachePaths
MATLAB=/mnt/data/izaak/matlab-7.10/bin/matlab
MERGEDPATH=/tmp/merged_cache.mat
