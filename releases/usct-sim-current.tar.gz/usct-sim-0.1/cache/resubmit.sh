#!/bin/bash
grep "Unable to read file /storage/home/izaak/usct_workdir/exp28" processMultiple2.sh.e* | sed 's/:.*//' | sed 's/.*e//' > /tmp/failed
for job in `cat /tmp/failed`; do echo "qsub `qstat -xf $job | grep args | sed 's/.*<submit_args>//' |sed 's/<\/submit_args>.*//'`"; done
