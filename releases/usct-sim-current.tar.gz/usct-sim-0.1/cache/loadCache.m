function cache = loadCache(key,cachePath)

system(['lockfile ' cachePath '/' key '.lock']);
load([cachePath '/' key]);
system(['rm -f ' cachePath '/' key '.lock']);

