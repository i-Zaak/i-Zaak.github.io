savePath = '/scratch/izaak/usct_workdir/exp33'
load([savePath '/allEmitters']);
step= 20;
for i=801:step:900%size(allCoords,1)
    i_end = i+step-1
    if i_end > size(allCoords,1)
        i_end = size(allCoords,1)
    end
    [status, result] = system( ['qsub -Wgroup_list=feec -q feec -l mem=1300mb -l nodes=1:ppn=1 -l matlab=1 -v USCT_START=' int2str(i) ',USCT_STOP=' int2str(i_end) ' precomputeMultipleScatterers.sh'])
    %[status, result] = system( ['qsub -q backfill -l mem=2gb -l nodes=1:ppn=1 -v USCT_START=' int2str(i) ',USCT_STOP=' int2str(i_end) ' precomputeMultipleScatterers.sh'])
    pause(0.1)
end
quit
