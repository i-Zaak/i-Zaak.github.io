function out = CreateGeometryFile(path,fileName,coordinateSystemType,diameterCylinder,deltaSender,numberOfSenderLayers,numberOfSendersPerLayer,offsetSender,deltaReceiver,numberOfReceiverLayers,numberOfReceiversPerLayer,offsetReceiver)

% Description: creates two geometry files (sender and receiver) for ideal cylinder geometry, at the moment only cartesian coordinates
%              new == we need to define the 0 positions of the middle layer (second tas row) at the motorposition 0
%              additionally the normal vectors for the transducers
% 
% Definitions:  A first specification of the origin of this coordinate system (cartesian) is arbitrarily chosen to lie at the top 
%               of the cylinder (0 of the az-coordinate) and in the middle of the cylinder in this slice ((0,0) of the 
%               ax-ay-coordinates). The (1,0) vector of the ax-coordinate is normal to and directed toward the plane of a line 
%               through the senders of the first TAS on the first board (see logical coordinate system) and the tangent to the 
%               cylinder through this line. The (0,1) vector of the ay-coordinate system lies parallel to this plane and the 
%               90�angle between (1,0) and (0,1) is counterclockwise. 
%               All numbers are in millimeters.
%
% Input:    path:                       folder superstructure
%           fileName:                   name of new geometry files, will be extended with _sender.mat and _receiver.mat
%           typeOfCoordinateSystem:     type of the used coordinate system (cartesian) 
%           diameterCylinder:           diameter of the cylinder (ax/ay)
%           deltaSender:                distance between two sender layer
%           numberOfSenderLayers:       number of sender layers (in az direction)
%           numberOfSendersPerLayer:    number of senders per layer (in ax/ay direction)
%           offsetSender:               vector of offset for first sender in respect to origin of coordinate system 
%           deltaReceivers:             distance between two receiver layers
%           numberOfreceiverLayers:     number of receiver layers (in az direction)
%           numberOfreceiversPerLayer:  number of receivers per layer (in ax/ay direction)
%           offsetReceiver:             vector of offset for receiver in respect to origin of coordinate system 
%
% Output:  > 0 file successfully written
% 
% author: n.ruiter 
% ersterstellungsdatum: 9.8.2004
% letzte aenderung: 28.4.2005 %15.02.2005 %11.8.2004

%Init of offset for middle tas row
deltaAngle = -(3*(360/(16*6)))*pi/180; %+(3*(360/(16*6)))*pi/180; for left hand side
minMiddleLayerReceiver = 17;
maxMiddleLayerReceiver = 32;
minMiddleLayerSender = 9;
maxMiddleLayerSender = 16;

%All parameters available?
if (exist('path')==0 | exist('fileName')==0 | exist('coordinateSystemType') == 0 | exist('diameterCylinder')==0 | exist('numberOfSenderLayers')==0 | exist('numberOfSendersPerLayer')==0 | exist('offsetSender')==0 | exist('numberOfReceiverLayers')==0| exist('numberOfReceiversPerLayer')==0 | exist('offsetReceiver')==0 | exist('deltaSender')==0 | exist('deltaReceiver')==0) 
    disp('CriticalError: Incomplete ParameterString');
    out = 0;
    return
end

% Simple test of plausability of the parameters
if (diameterCylinder<=0 | numberOfSenderLayers <= 0 | numberOfSendersPerLayer <= 0 | numberOfReceiverLayers <= 0 | numberOfReceiversPerLayer <= 0 | deltaSender  <= 0 | deltaReceiver <= 0)
    disp('CriticalError: Parameter(s) too small ');
    out = 0;
    return
end

[alphaSenderOffset,rhoSenderOffset] = cart2pol(offsetSender(1,1),offsetSender(1,2));
[alphaReceiverOffset,rhoReceiverOffset] = cart2pol(offsetReceiver(1,1),offsetReceiver(1,2));
radiusCylinder=0.5*diameterCylinder;
if (round(radiusCylinder)~=round(rhoSenderOffset)|round(radiusCylinder)~=round(rhoReceiverOffset))
    disp('CriticalError: Offset(s) not on cylinder surface');
    out = 0;
    return
end

% Only cartesian coordinate system implemented at the moment
if(coordinateSystemType~='cartesian')
    disp('Only cartesian coordinate systems at the moment');
    out = 0;
    return
end

%File already there? If yes, do not override
senderFileName = [fileName '_sender.mat'];
completePathSender = fullfile(path,senderFileName);
senderFileExists = 1;
receiverFileName = [fileName '_receiver.mat'];
completePathReceiver = fullfile(path,receiverFileName);
receiverFileExists = 1;

try load(completePathSender);
   catch senderFileExists=0;
end

try load(completePathReceiver);
   catch receiverFileExists=0;
end

if(senderFileExists|receiverFileExists)
    disp('File(s) exist(s) already');
    out = 0;
    return
end

%Now create the files
dimensions = 3; %3D
%sender file
deltaZ = deltaSender;
deltaAlpha = -2*pi/numberOfSendersPerLayer;%-2*pi/numberOfSendersPerLayer; for left hand side coord sys
elementPositions = zeros(numberOfSenderLayers,numberOfSendersPerLayer,dimensions);
normals = zeros(numberOfSenderLayers,numberOfSendersPerLayer,dimensions);
for(layer=1:1:numberOfSenderLayers)
    azPos = offsetSender(1,3)+(layer-1)*deltaZ; 
    for(sender=1:1:numberOfSendersPerLayer)
        aktAlpha = alphaSenderOffset + (sender-1)*deltaAlpha;
        if(layer>=minMiddleLayerSender & layer<=maxMiddleLayerSender) %if middle layer Tas
            [elementPositions(layer,sender,1),elementPositions(layer,sender,2)] = pol2cart(aktAlpha+deltaAngle,radiusCylinder);            
        else %if upper or lower layer
            [elementPositions(layer,sender,1),elementPositions(layer,sender,2)] = pol2cart(aktAlpha,radiusCylinder);            
        end
        elementPositions(layer,sender,3) = azPos;   
        %Normal 
        normals(layer,sender,:) = [(-elementPositions(layer,sender,1)) (-elementPositions(layer,sender,2))  0]';
        normals(layer,sender,:) = normals(layer,sender,:)/norm([normals(layer,sender,1) normals(layer,sender,2)]);
    end
end

try save(completePathSender,'coordinateSystemType','elementPositions','normals');
   catch disp('Cound not write sender file');
   out = 0;
   return    
end 

%receiver file
deltaZ = deltaReceiver;
deltaAlpha = -2*pi/numberOfReceiversPerLayer;%-2*pi/numberOfReceiversPerLayer; for left hand side
elementPositions = zeros(numberOfReceiverLayers,numberOfReceiversPerLayer,dimensions);
normals = zeros(numberOfSenderLayers,numberOfSendersPerLayer,dimensions);
for(layer=1:1:numberOfReceiverLayers)
    azPos = offsetReceiver(1,3)+(layer-1)*deltaZ; 
    for(receiver=1:1:numberOfReceiversPerLayer)
        aktAlpha = alphaReceiverOffset + (receiver-1)*deltaAlpha;
        if(layer>=minMiddleLayerReceiver & layer<=maxMiddleLayerReceiver) %if middle layer Tas
            [elementPositions(layer,receiver,1),elementPositions(layer,receiver,2)] = pol2cart(aktAlpha+deltaAngle,radiusCylinder);            
        else
            [elementPositions(layer,receiver,1),elementPositions(layer,receiver,2)] = pol2cart(aktAlpha,radiusCylinder);            
        end
        elementPositions(layer,receiver,3) = azPos;
        %Normal 
        normals(layer,receiver,:) = [(-elementPositions(layer,receiver,1)) (-elementPositions(layer,receiver,2))  0]';
        normals(layer,receiver,:) = normals(layer,receiver,:)/norm([normals(layer,receiver,1) normals(layer,receiver,2)]);
    end
end

try save(completePathReceiver,'coordinateSystemType','elementPositions','normals');
   catch disp('Could not write receiver file');
   out = 0;
   return    
end 

out=1;
