function [ ] = preprocess( handles, voxelModel )
% Wrapper function for main simulation. NEEDS MAJOR REFACTORING!
    Dir = get(handles.edit_adr, 'String');
    val = get(handles.list_map,'Value');
    str = get(handles.list_map, 'String');
    
    parametry_name = [Dir,'/parameters.mat'];
    param = load(parametry_name);
    modelSize = size(voxelModel(:,:,:,1));
    
    statsDataRoot ='/data/usct_data/noise_amplitude_stats2';
    

    
    N_spect = param.vzorkovaci_spektrum; N_spect = str2num(N_spect);
    fs = param.vzorkovaci_frekvence; fs = str2num(fs);fs=fs*10e5;   % [Hz] (sampling freq.)
    T = 1/fs;   % [s] (sampling period)
    f0 = param.Stredni_frekvence; f0 = str2num(f0);f0=f0*10e5;  % [Hz] (pulse freq.)
    nn = param.nn; nn = str2num(nn);
    c = 1498;  % [m/s]
    savePath = param.cesta_ulozeni;
    

    %%  modeled sent pulse (ideal)
    NP = 32;
    t=(0:NP-1)*T;
    pulse = cos(f0*2*pi*t') .* gausswin(NP);
    P = fft(pulse,N_spect);




    %%  ziskani souradnic 3D modelu
    %set(0,'userdata',diameterCylinder);
    %create3DDemonstratorGeometry_model

    %FIXME
    %S=load([Dir '/coordinates/GeometryNormalsDiam0_18407_sender.mat']);
    %R=load([Dir '/coordinates/GeometryNormalsDiam0_18407_receiver.mat']);
    S=load([Dir '/coordinates/GeometryNormalsDiam0_18407_sender.mat']);
    R=load([Dir '/coordinates/GeometryNormalsDiam0_18407_receiver.mat']);
    %S = S.elementPositions;    
    %R = R.elementPositions;
    
    minX = min(min(R.elementPositions(:,:,1)));
    maxX = max(max(R.elementPositions(:,:,1)));
    minY = min(min(R.elementPositions(:,:,2)));
    maxY = max(max(R.elementPositions(:,:,2)));
    minZ = min(min(R.elementPositions(:,:,3)));
    maxZ = max(max(R.elementPositions(:,:,3)));
    
    pixelSize = (maxX-minX)/(modelSize(1)-2); % predpoklada ctvercove obrazky. FIXME validace! 
    
    extrem = zeros(3,2);
    extrem(1,1)=minX - 1*pixelSize;
    extrem(2,1)=minY - 1*pixelSize;
    extrem(3,1)=minZ - 1*pixelSize;
    %extrem(:,2)=modelSize;
    extrem(1,2)=maxX + 1*pixelSize;
    extrem(2,2)=maxY + 1*pixelSize;
    extrem(3,2)=minZ + modelSize(3)*pixelSize + 1;
    
    extrem(:,1) = extrem(:,1) + 0.1; % FIXME careful!
    extrem(:,2) = extrem(:,2) + 0.1; % FIXME careful!
    
    
    %global voxels;
    %voxels = zeros(512,512,20);
    
    sl_range = get (handles.sl_rangeEE,'string');
    rl_range = get(handles.rl_rangeEE,'string');
    
    %store the experiment parameters
    expParamPath = [savePath '/expParam.mat'];
    save(expParamPath, 'pixelSize', 'extrem', 'N_spect','fs', 'f0', 'P', 'nn' );
    coordinates = [];
    for layerSender = (eval(sl_range)-1) %0:4 ;%12; %FIXME interval??    
        layer_dir = [savePath sprintf('/layerSender_%04d',layerSender)];
        mkdir(layer_dir);
        for senderNumber = 0:95  %pocet vysilacich prvku pri toceni motoru %FIXME interval?!
            motor_pos = mod(senderNumber, 6); % od 0 do 5
            sender_dir = [layer_dir sprintf('/senderNumber_%04d',senderNumber)];
            mkdir(sender_dir);
            %disp(sprintf('layerSender:%04d senderNumber:%04d',layerSender,senderNumber))

            Map = zeros (3,48*192);
            ascan = 0;         
            
            LayerS = 1+(layerSender);       % vrstva vysilace 0:23
            NumberS = 1+(senderNumber);     % cislo vysilace 0:95
            
            %FIXME
            %coordSender = getCoordinates(S,'cartesian',LayerS,NumberS);
            coordSender = getCoordinates(S,'cartesian',LayerS,NumberS) + 0.1; %FIXME EVIL HACK!!!
            %coordSender = squeeze(S(LayerS,NumberS,:))' + 0.1;
            coordinates = [];
            
            for layerReceiver = (eval(rl_range)-1) %0:7 %0:19 %24:25 %FIXME interval!?                
                 NumberR =  motor_pos*2 + 1; % pocatecni receiver element
                 delta_nr = 1; % prirustek pro inkrementaci NumberR v dalsim kroku (strida se 1 a 11)
   
                 for receiverindex = 0:31 %%%RRR160710 correct range
                    ascan = ascan + 1;
                    LayerR = 1+(layerReceiver);     % vrstva prijimace 0:47
                    
                    coordReceiver = getCoordinates(R,'cartesian',LayerR,NumberR)+ 0.1; %FIXME EVIL HACK!!!
   
                    statsFile = [statsDataRoot '/layerSender_'  sprintf('%04d', layerSender)  '/senderNumber_'  sprintf('%04d', senderNumber) '/stats.mat' ];
                    s = load(statsFile, 'stats');
                    stats = s.stats;
                    noisePosition = 0;
                    for i=1:size(stats,2)
                        if(stats(1,i) == layerReceiver && stats(2,i) == NumberR - 1)
                            noisePosition = i;
                        end
                    end
                    noise_std = stats(4,noisePosition);
                    amplitude = stats(5,noisePosition)/2;
                    
                    coordinates =[coordinates; squeeze(coordSender)' squeeze(coordReceiver)' noise_std amplitude];

                    Map(1, ascan) = layerReceiver;
                    Map(2, ascan) = NumberR - 1;  %receiverNumber;
                    NumberR = NumberR + delta_nr;
                    if delta_nr==1
                        delta_nr = 11;
                    else
                        delta_nr = 1;
                    end
                 end
            end
            Map = Map(:,1:ascan);
            save([sender_dir '/map'], 'Map');
            save([sender_dir '/raysCoordinates.mat'], 'coordinates');
        end
    end
    
end

