function [D,f] = directivity(a, c, theta, fs, NN)

% a - transducer radius [m]
% c - sound speed [m/s]
% theta - angle between the transducer's normal and the line connecting the transducer cetner and the interrogation point [deg]
% fs - sampling rate [Hz]
% NN - number of samples - should be an even number [-]

N=round(NN/2);
n = -N:(N-1);
f = fftshift(n/N*fs);
omega = 2*pi*f;
k = omega / c; % [1/m]

argument = a * k * sin(theta/180*pi);
%figure(1); plot(argument); pause
D = 2 * besselj(1,argument) ./ argument;
D(argument==0)=1;

D(NN/2+1:end-1) =  conj(fliplr(D(2:NN/2)));


%figure(1); 
%subplot(2,1,1);
%plot(abs(D)); 
%subplot(2,1,2);
%plot(angle(D)); pause(0.1)

%d = 2*pi/N * real(ifft(D));

%n(1)
%f(1)
%k(1)
%argument(1)
%D(1)
