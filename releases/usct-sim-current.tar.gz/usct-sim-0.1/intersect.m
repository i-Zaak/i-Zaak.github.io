clear

extrem(1,1)=0.0;
extrem(2,1)=0.0;
extrem(3,1)=0.0;
extrem(1,2)=1000.0;
extrem(2,2)=1000.0;
extrem(3,2)=1000.0;

steps(1)=50;
steps(2)=50;
steps(3)=50;

beamEnds=[280.2 1000 590; 520 0 35]'
%beamEnds=[5  10 0; 70 50 100]';

% =======================================================
vecX=extrem(1,1):steps(1):extrem(1,2);
vecY=extrem(2,1):steps(2):extrem(2,2);
vecZ=extrem(3,1):steps(3):extrem(3,2);
%[gridX, gridY, gridZ]=meshgrid(vecX,vecY,vecZ);
numX=length(vecX);
numY=length(vecY);
numZ=length(vecZ);

figure('Position', [10 10 800 800],'DoubleBuffer','on',...       
 'Color',[1 1 1],...
 'InvertHardcopy','off',... 
 'Name','Force-displacement Curves',...
 'XVisual','0x23 (TrueColor, depth 32, RGB mask 0xff0000 0xff00 0x00ff)');
hold on
%stem3(gridX, gridY, gridZ,'LineStyle','none','MarkerSize',0,'MarkerFaceColor','blue');
line(beamEnds(1,:), beamEnds(2,:), beamEnds(3,:), 'Color' , 'red', 'LineWidth',6)
%--------------------------------------------------------------------

beamVec = beamEnds(:,2) - beamEnds(:,1);

beamEq = [beamEnds(:,1) beamVec];

intCoors=zeros(numX+numY+numZ,3);

numInt=0;
if (beamEq(1,2) ~= 0.0)
	for i=1:length(vecX)
		linePar=(vecX(i) - beamEq(1,1))/beamEq(1,2);
		intPoint = beamEq(:,1) + beamEq(:,2)*linePar;
		if (intPoint(2) >= extrem(2,1) & intPoint(2) <= extrem(2,2) & intPoint(3) >=extrem(3,1) & intPoint(3) <=extrem(3,2))
			numInt=numInt+1;
			intCoors(numInt,:) = intPoint;
			intParam(numInt) = linePar;
			intType(numInt) = 1;
		end
	end
end

if (beamEq(2,2) ~= 0.0)	
	for i=1:length(vecY)
		linePar=(vecY(i) - beamEq(2,1))/beamEq(2,2);
		intPoint = beamEq(:,1) + beamEq(:,2)*linePar;
		if (intPoint(1) >= extrem(1,1) & intPoint(1) <= extrem(1,2) & intPoint(3) >= extrem(3,1) & intPoint(3) <= extrem(3,2))
			numInt=numInt+1;
			intCoors(numInt,:) = intPoint;
			intParam(numInt) = linePar;
			intType(numInt) = 2;
		end
	end
end

if (beamEq(3,2) ~= 0.0)	
	for i=1:length(vecZ)
		linePar=(vecZ(i) - beamEq(3,1))/beamEq(3,2);
		intPoint = beamEq(:,1) + beamEq(:,2)*linePar;
		if (intPoint(1) >= extrem(1,1) & intPoint(1) <= extrem(1,2) & intPoint(2) >= extrem(2,1) & intPoint(2) <= extrem(2,2))
			numInt=numInt+1;
			intCoors(numInt,:) = intPoint;
			intParam(numInt) = linePar;
			intType(numInt) = 3;
		end
	end
end

[intParamSort,indsSort]=sort(intParam);
[intParamUniq, indsUniq] = unique(intParamSort);
indsFinal = indsSort(indsUniq);
coorsFinal = intCoors(indsFinal,:);
%==========================================================================




line(coorsFinal(:,1), coorsFinal(:,2), coorsFinal(:,3), 'Color','green', 'LineStyle','-', 'LineWidth',5, 'Marker','x')
%stem3(coorsFinal(:,1), coorsFinal(:,2), coorsFinal(:,3), 'Color', 'cyan','LineStyle','none','MarkerSize',5, 'MarkerFaceColor','black');


coorsFinal;

faces=[1 2 6 5; 2 3 7 6; 3 4 8 7; 4 1 5 8; 1 2 3 4; 5 6 7 8];
len=0.0;
for vox=1:(length(coorsFinal) - 1)
	pointIn = coorsFinal(vox,:);
	pointOut = coorsFinal(vox+1,:);
	pointAv=0.5*(pointIn+pointOut);
	for i=1:3
		voxel(1,i)=floor((pointAv(i) - extrem(i,1))/steps(i))*steps(i) + extrem(i,1);
		voxel(2,i)=voxel(1,i) + steps(i);		
	end
	for i=1:2		
		for j=1:2
			for k=1:2		
				cubeX(4*(k-1)+2*(j-1)+i,:)=[voxel(i,1) voxel(j,2) voxel(k,3)];
			end
		end
	end
    cube=cubeX;
	cube(3,:)=cubeX(4,:); cube(4,:) = cubeX(3,:);
	cube(7,:)=cubeX(8,:); cube(8,:) = cubeX(7,:);
	patch('Vertices',cube, 'Faces',faces,'FaceColor','magenta', 'FaceAlpha',0.3); %'FaceVertexCData',hsv(6),'FaceColor','flat');
	len=len+norm(pointOut-pointIn);
end

for i=1:2		
	for j=1:2
		for k=1:2		
			cubeX(4*(k-1)+2*(j-1)+i,:)=[extrem(1,i) extrem(2,j) extrem(3,k)];
		end
	end
end
bigCube=cubeX;
bigCube(3,:)=cubeX(4,:); bigCube(4,:) = cubeX(3,:);
bigCube(7,:)=cubeX(8,:); bigCube(8,:) = cubeX(7,:);

patch('Vertices',bigCube, 'Faces',faces,'FaceColor','yellow', 'FaceAlpha',0.2); 
set(gca,'DataAspectRatio',[1 1 1])
format long
perPieces=len
segment = norm(beamEnds(:,1) - beamEnds(:,2))

    az = 52;
    el = -20;
    view(29, 34);
    grid on	

