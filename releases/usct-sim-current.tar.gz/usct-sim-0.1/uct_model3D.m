profile on
%  cd F:\Upload\software\simulace_3D_dat

h = get(0,'userdata');
% Dir = get(h.edit_adr, 'String'); % directory with map
% cd (Dir)
%Dir_coor='\coordinates';
%Dir2=[Dir,Dir_coor];
%addpath(Dir2);
%addpath(pwd);
% model_name = '.'; %'mereni_3D';
% out_dir = [model_name];
% realAdr = cd ();
% % mkdir(out_dir);

%% Directory with phantom, coordinates and 'parametry.mat'
h = get(0,'userdata');
Dir = get(h.edit_adr, 'String');
val = get(h.list_map,'Value');
str = get(h.list_map, 'String');
%FIXME mapa_name = [Dir,'\',str{val}];
%FIXME map_vel_att_name = [Dir,'\',str{val},'.att_vel_scat.mat'];
mapa_name = [Dir,'/',str{val}];
map_vel_att_name = [Dir,'/',str{val},'.att_vel_scat.mat'];

parametry_name = [Dir,str{val},'.parameters.mat'];
%%  nacteni parametru z uzivatelskeho prostredi GUIDE
param = load(parametry_name);

N_spect = param.vzorkovaci_spektrum; N_spect = str2num(N_spect);
fs = param.vzorkovaci_frekvence; fs = str2num(fs);fs=fs*10e5;   % [Hz] (sampling freq.)
T = 1/fs;   % [s] (sampling period)
f0 = param.Stredni_frekvence; f0 = str2num(f0);f0=f0*10e5;  % [Hz] (pulse freq.)
nn = param.nn; nn = str2num(nn);
radius2 = param.radius; radius2 = str2num(radius2);
c = 1498;  % [m/s]
diameterCylinder = radius2;
radius = radius2 / 2;
ztop = param.ztop; ztop = str2num(ztop);   % [m] vrchni cast fantomu
zbottom = param.zbottom; zbottom = str2num(zbottom);    % [m] spodni cast fantomu
savePath = param.cesta_ulozeni;

%% nacteni nove preddefinovane mapy utlumu a rychlosti
mapa = double(imread(mapa_name));   % obrazek
map_number = load(map_vel_att_name);

grey = map_number.map_mat;
atten = map_number.map_att;
map_att = mapa;

for i = 1:length(grey)-1
    map_att((map_att>=grey(i))&(map_att<grey(i+1)))=atten(i); % prevedeni intervalu stupnu sedi na jeden z koeficientu
end
map_att(map_att==grey(length(grey)))=atten(length(grey));

veloc = map_number.map_vel;
map_vel = mapa;

for i = 1:length(grey)-1
    map_vel((map_vel>=grey(i))&(map_vel<grey(i+1)))=veloc(i);
end
map_vel(map_vel==grey(length(grey)))=veloc(length(grey));




%%KRATOCHVILA
% echogen = map_number.map_echo;
% map_echo = mapa;
% for i = 1:length(grey)-1
%     map_echo((map_echo>=grey(i))&(map_echo<grey(i+1)))=echogen(i);
% end
% map_echo(map_echo==grey(length(grey)))=echogen(length(grey));

% %%KRATOCHVILA
% x_odr=0.0312;
% y_odr=0.0312;
% z_odr=0.0955;
% sour_odrazec=[x_odr,y_odr,z_odr];
% echogenita = 0.5;

% % Ohniska
%     x_ohn=zeros(20,1);
%     y_ohn=zeros(20,1);
%     z_ohn=0.0955;
% for i=1:20
%     y_ohn(i)=-0.08+0.005*i;
% %     x_ohn(i)=0.0312;
% end





%%  rucni nastaveni parametru simulace
% N_spect= 128; % number of samples for spectrum
% c = 1498;  % [m/s]
% fs = 20e6; % [Hz] (sampling freq.)
% T = 1/fs;  % [s] (sampling period)
% f0 = 3e6;  % [Hz] (pulse freq.)
% nn = 1;   % koeficient nelinearity
% zt = 0.0523;     % nastaveni vrchni casti fantomu 0.022-prvni pozice
% zb = 0.055;    % nastaveni spodni casti fantomu 0.1630-posledni pozice
%%  rucni nastaveni velikosti nadoby simulatoru
% diameterCylinder = 0.18407; 
% set(0,'userdata',diameterCylinder);
%%  rucni nastaveni rychlosti a utlumu uzv v prostredi
% map attenuation
% map_att = double(imread('map_att_vel.bmp'));  %nutnost predelani do prostredi guide
% map_att = map_att / max(max(map_att));
% 
% % map velocity
% map_vel = double(imread('map_att_vel.bmp'));
% map_vel(map_vel<0.3) = 1483;    %Voda
% map_vel(map_vel<100) = 1535;    %Karcinom   97=0.6235
% map_vel(map_vel<200) = 1514;    %Cysta      197=0.3804
% map_vel(map_vel<=255) = 1568;   %Sval       255=1

%%  modeled sent pulse (ideal)
NP = 32;
t=(0:NP-1)*T;
pulse = cos(f0*2*pi*t') .* gausswin(NP);
P = fft(pulse,N_spect);
P0 = P;
% figure(1);plot(pulse);pause;
%return

% frequency
f = [(0:N_spect/2-1) (-N_spect/2:-1)]';
f = f * fs / N_spect;

model_name = 'mereni_3D'
% map_att = zeros(size(map_att)); %%%%%%%%%%%%%%%%%%%%%%%%%%%%!!!!!!!!!!!!!!!!!!!
% model_name = 'mereni_3D_prazdne'
out_dir = [model_name];
realAdr = cd ();


%%  ziskani souradnic 3D modelu
set(0,'userdata',diameterCylinder);
create3DDemonstratorGeometry_model

S=load([Dir '/coordinates/GeometryNormalsDiam0_18407_sender.mat']);
R=load([Dir '/coordinates/GeometryNormalsDiam0_18407_receiver.mat']);

[YA XA] = size(map_vel);

%return
%mkdir(savePath);


%%%RRR:
%for layerSender = 0:23  %pocet vrstev vysilacich prvku
for layerSender = 0:2;
%FIXME for layerSender = (eval(sl_range)-1) %0:4 ;%12;
    
    layer_dir = [savePath sprintf('/layerSender_%04d',layerSender)];
    mkdir(layer_dir);
    %cd (layer_dir);
    for senderNumber = 0:5  
    %FIXME for senderNumber = 0:95  %pocet vysilacich prvku pri toceni motoru
        
        motor_pos = mod(senderNumber, 6); % od 0 do 5
        
        sender_dir = [layer_dir sprintf('/senderNumber_%04d',senderNumber)];
        mkdir(sender_dir);
        %cd(sender_dir);
        
        disp(sprintf('layerSender:%04d senderNumber:%04d',layerSender,senderNumber))
        
        %cd ([realAdr]);     % pristup k ostatnim m-files
        
%         AScans = zeros(3500,1536);
%         Map = zeros (3,1536);
%         AScans = zeros(3500,8*192);
        AScans = zeros(3500,8*32);
% KRATOCHVILA (2 radky)
%                 AScans1 = zeros(3500,20*192);
% %                AScans2 = zeros(3500,48*192);

        Map = zeros (3,48*192);
        ascan = 0;
        
%%%RRR:
%        for layerReceiver = 0:47 %3x8x2 pocet prijimacich vrstev
         %for layerReceiver = 18:29
         %FIXME for layerReceiver = (eval(rl_range)-1) %0:7 %0:19 %24:25
         for layerReceiver = 0:2 %0:19 %24:25
            
             %              disp(sprintf('layerReceiver:%d',layerReceiver)) % zobrazeni po prijimanych vrstvach
            
             NumberR = motor_pos*2 + 1; % pocatecni receiver element
             delta_nr = 1; % prirustek pro inkrementaci NumberR v dalsim kroku (strida se 1 a 11)
             %!!!
             %for receiverindex = 0:191 %0:31
             %FIXME for receiverindex = 0:31
             for receiverindex = 0:5

                %!!!
                %NumberR = 1 + receiverindex;
                ascan = ascan + 1;
                                
%%          souradnice a vzdalenost ep-sp: p??????m??? impulz
                
                LayerS = 1+(layerSender);       % vrstva vysilace 0:23
                NumberS = 1+(senderNumber);     % cislo vysilace 0:95
                coordSender = getCoordinates(S,'cartesian',LayerS,NumberS);
                
                xS=coordSender(1);
                yS=coordSender(2);
                zS=coordSender(3);
                
                LayerR = 1+(layerReceiver);     % vrstva prijimace 0:47
                %NumberR = 1+(pom2*6) + motor_pos;   % cislo prijimace 0:191
                coordReceiver = getCoordinates(R,'cartesian',LayerR,NumberR);
                
                xR=coordReceiver(1);
                yR=coordReceiver(2);
                zR=coordReceiver(3);
                
                len_xy = sqrt((xS-xR)^2+(yS-yR)^2);
                len = sqrt((xS-xR)^2+(yS-yR)^2+(zS-zR)^2);
% KRATOCHVILA doplnuje s vyuzitim odrazece (1 radek):
%                len_odr = sqrt((xS-x_odr)^2+(yS-y_odr)^2+(zS-z_odr)^2)+sqrt((x_odr-xR)^2+(y_odr-yR)^2+(z_odr-zR)^2);

 % KRATOCHVILA doplnuje vzdalenosti k ohniskum:
%                 Nejprve potrebuji ziskat koordinaty vysilaciho a nasledujicich
%                 prijimacich mist (fokusace v prijmu - nekolik prijimacu)
%                 
%                 coordSender_fokus = getCoordinates(S,'cartesian',13,1);
%                 xS_stabil=coordSender_fokus(1);
%                 yS_stabil=coordSender_fokus(2);
%                 zS_stabil=coordSender_fokus(3);
%                 
% %                 receiverindex_stabil=receiverindex(1);
%                 xR_fokus=zeros(3,1);
%                 yR_fokus=zeros(3,1);
%                 zR_fokus=zeros(3,1);  
%                 for i=1:3
%                 NumberR_fokus = i;
%                 coordReceiver_fokus = getCoordinates(R,'cartesian',25,NumberR_fokus);
%                 
%                 xR_fokus(i)=coordReceiver_fokus(1);
%                 yR_fokus(i)=coordReceiver_fokus(2);
%                 zR_fokus(i)=coordReceiver_fokus(3);                
%                 end;
%                 rezimprijmu = zeros(20,3);
%                 for i=1:20
%                     for j=1:3
%                 rezimprijmu(i,j) = sqrt((xS_stabil-x_ohn(i))^2+(yS_stabil-y_ohn(i))^2+(zS_stabil-z_ohn)^2)+sqrt((x_ohn(i)-xR_fokus(j))^2+(y_ohn(i)-yR_fokus(j))^2+(z_ohn-zR_fokus(j))^2);
%                     end             
%                 end;        
%                save('Kratochvila_vzdalenosti','rezimprijmu');
% 
%                 P = fft(pulse,N_spect);
%                 Pp= fft(pulse,N_spect);
%%          get velocity and attenuation !!!!!!!

                x1 = xS; y1 = yS; z1 = zS;
				x2 = xR; y2 = yR; z2 = zR;
                
                konstSample = XA/diameterCylinder;
                vrstev = round(abs(z1-z2)* konstSample);

                uct_model_get_xy_view;  % returns layer xy view
                
                [SZ SX] = size(resultB_xy);
                
                uct_model_get_att_vel;  % returns betad and tcel
%%              
                P = P0 .* exp(-betad.* (abs(f).^nn) );   %nelinearni zavislost f na beta
%                 P = P .* exp(-betad.*abs(f));     %linearni zavislost

                %figure(2);subplot(3,1,2);plot(abs(P));
                %figure(2);subplot(3,1,3);plot(exp(-betad.*abs(f)));
                
                p = real(ifft(P));
                %betad
       		    %figure(1); plot (p); pause
%                 pp = real(ifft(Pp));                
%%          get position in the RF signal:
%      KRATOCHVILA - uprava matic AScans
                pos = round(tcel/T); 
                AScans((1+pos):(pos+N_spect),ascan) = AScans((1+pos):(pos+N_spect),ascan) + p/len;
%                 rychlostuzv=1483;
%                 casuseku=len/rychlostuzv; %DOTAZ NA uct_model_get_att_vel radek 49-51 ??? Proc tak slozite?
%                 pos = round(casuseku/T);
%                 AScans1((1+pos):(pos+N_spect),ascan) = AScans1((1+pos):(pos+N_spect),ascan) + pp/len;
% %Nyn??? pro odra???e???:
%                 
%                 casuseku2=len_odr/rychlostuzv; %DOTAZ NA uct_model_get_att_vel radek 49-51 ??? Proc tak slozite?
%                 pos2 = round(casuseku2/T); 
%                 AScans2((1+pos2):(pos2+N_spect),ascan) = AScans2((1+pos2):(pos2+N_spect),ascan) + echogenita*pp/len_odr;
% 
% % KRATOCHVILA - ziskani indexu v matici AScans pro ohniska, kde jest:              
%                 casuseku_rezimprijmu=zeros(20,3);
%                 pos_rezimprijmu = zeros(20,3);
%                 rychlostuzv=1483;
%              for i=1:20
%                 for j=1:3
%                 casuseku_rezimprijmu(i,j)=rezimprijmu(i,j)/rychlostuzv; %DOTAZ NA uct_model_get_att_vel radek 49-51 ??? Proc tak slozite?
%                 pos_rezimprijmu(i,j) = round(casuseku_rezimprijmu(i,j)/T);
%                 end;
%              end;
%              save('Kratochvila_poziceindexy','pos_rezimprijmu');
% 
% %                 senderNumber+1
% %                 NumberR
% %                 pos
% %                 tcel
% %                 len/tcel
% %                 pause
%                 
% %                 figure(1);imagesc(resultV_xy);
% %                 pause
%                 
% %                 cd ([savePath]); cd(layer_dir); cd(sender_dir);
                
                Map(1, ascan) = layerReceiver;
                Map(2, ascan) = NumberR - 1;  %receiverNumber;

%                 test_beta(ascan) = betad;
%                 test_NumberR(ascan) = NumberR;
                

                NumberR = NumberR + delta_nr;
                if delta_nr==1
                    delta_nr = 11;
                else
                    delta_nr = 1;
                end
                   
                %figure(1);plot(AScans(1:end,ascan));pause
            end
            
            %return
            
         end
        
 
         
         
    %KRATOCHVILA SOUCET Ascansu bez a s odrazecem    
%         AScans1 = AScans1(:,1:ascan);
% %         AScans2 = AScans2(:,1:ascan);
%         AScans = AScans1; %+AScans2;
        AScans = AScans(:,1:ascan);
        Map = Map(:,1:ascan);
          
        %cd ([savePath]);cd(layer_dir); cd(sender_dir);
        save([sender_dir '/data'], 'AScans', 'Map');

        
        %cd ..

    end
     
    %cd ..
    
end

profile off
profsave