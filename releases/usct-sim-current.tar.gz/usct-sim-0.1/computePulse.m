function [p pos] = computePulse( betad, time, P0, f, nn, T)
    P = P0 .* exp(-betad.* (abs(f).^nn) );   %nelinearni zavislost f na beta
    p = real(ifft(P));
    pos = round(time/T);
end

