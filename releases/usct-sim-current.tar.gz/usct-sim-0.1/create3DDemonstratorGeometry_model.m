function f = create3DDemonstratorGeometry()

% mkdir ('mereni_3D','coordinates');
% path = 'mereni_3D/coordinates';
% path = 'D:/VUT/pokusny/coordinates'
% mkdir ('coordinates');
% path = 'coordinates';

fileName = 'GeometryNormalsDiam0_18407';
coordinateSystemType = 'cartesian';

% diameterCylinder = 0.18407;%0.18428;%0.18455;%sqrt(0.18455^2-2*0.0015^2) %in m sqrt(0.1843^2-2*0.0015^2)
diameterCylinder = get(0,'userdata');
numberOfSenderLayers = 24;
numberOfSendersPerLayer = 96;

numberOfReceiverLayers = 48;
numberOfReceiversPerLayer = 192;
[x,y] = pol2cart(0,(0.5*diameterCylinder));
offsetReceiver = [x,y,0.022];
deltaReceiver = 2*0.0015;

alphaOffsetSender = -0.5*(2*pi/numberOfReceiversPerLayer); %+ 0.5*(2*pi/numberOfReceiversPerLayer) for left hand
[x,y] = pol2cart(alphaOffsetSender,(0.5*diameterCylinder));
%[x,y] = pol2cart(0,(0.5*diameterCylinder));
offsetSender = [x,y,0.0235];
deltaSender = 4*0.0015;

f = CreateGeometryFile(path,fileName,coordinateSystemType,diameterCylinder,deltaSender,numberOfSenderLayers,numberOfSendersPerLayer,offsetSender,deltaReceiver,numberOfReceiverLayers,numberOfReceiversPerLayer,offsetReceiver);
%f = CreateGeometryFileWrongMR(path,fileName,coordinateSystemType,diameterCylinder,deltaSender,numberOfSenderLayers,numberOfSendersPerLayer,offsetSender,deltaReceiver,numberOfReceiverLayers,numberOfReceiversPerLayer,offsetReceiver);
