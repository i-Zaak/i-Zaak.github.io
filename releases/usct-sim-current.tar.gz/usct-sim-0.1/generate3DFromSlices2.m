function [ voxelMatrix] = generate3DFromSlices2( slices, height, width)
% Generates volumetrical data based on given slices.
% Height and width is in arbitrary but same units.


X = size(slices,1);
Y = size(slices,2);
n = size(slices,3);
Z = ceil(height*X/width);

pixelSize = width/X;
modelHeight = Z*pixelSize;
sliceDelta = height/(n-1);

voxelMatrix = zeros(X,Y,Z);

for l=1:Z
  layerCenter = (l-1)*pixelSize + pixelSize/2;
  slice = round(layerCenter/sliceDelta)+1;
  voxelMatrix(:,:,l) = slices(:,:,slice);
end
