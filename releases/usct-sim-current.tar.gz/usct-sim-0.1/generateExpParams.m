function [ expParamsPath ] = generateExpParams( storePath, fs, nn, rad_fun, pulseFunction, f0, a, c)
% default values:
%   pulseFunction  function generating the pulse
%   %N_spect = 128  sampling spectrum
%   fs = 10000000  sampling frequency [Hz]
%   f0 = 3000000   middle frequency FIXME translation of "stredni frekvence"
%   nn = 1 nonlinear koefficient of attenuation
%   rad_fun = 'homoRadiation' homegeneous radiation characteristic
%   a = sqrt(1.4e-6/pi) trasducer radius [m]
%   c = 1490 sound speed [m/s]

if nargin < 8
    c=1490;
    fprintf('c was set to default %f\n',  c);
end
if nargin < 7
    a=sqrt(1.4e-6/pi);
    fprintf('a was set to default %f\n',  a);
end
if nargin < 6
    f0 = 3000000;
    fprintf('f0 was set to default %f\n',  f0);
end
if nargin < 5
    pulseFunction = 'simplePulse';
    fprintf('pulseFunction was set to default %s\n', pulseFunction);
end
if nargin < 4
    rad_fun = 'homoRadiation';
    fprintf('rad_fun was set to default %s\n', rad_fun);
end
if nargin < 3
    nn = 1;
    fprintf('nn was set to default %f\n',  nn);
end
if nargin < 2
    fs = 10000000;
    fprintf('fs was set to default %f\n',  fs);
end


pulseFun = eval(['@' pulseFunction]);
[P N_spect] = pulseFun(fs,f0);

%T = 1/fs;
%NP = 32;
%t=(0:NP-1)*T;
%pulse = cos(f0*2*pi*t') .* gausswin(NP);
%P = fft(pulse,N_spect);
expParamsPath = [storePath '/expParams.mat'];
save( expParamsPath, 'N_spect', 'fs', 'f0', 'P', 'nn', 'rad_fun','pulseFunction','a','c');
