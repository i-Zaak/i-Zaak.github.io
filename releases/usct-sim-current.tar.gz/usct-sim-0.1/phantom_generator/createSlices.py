from __future__ import division
import math,os
import scipy.io as sio

bottom = 0.0
top = 163
slices = 460
canvasSize = 180
resolution = 512


zdelta = top/slices
height = abs(bottom - top)
verticalResolution = int(math.ceil( height* (resolution/canvasSize) ))
density = round(resolution/canvasSize*72)


#centers = [ 
#	    [90,90,0],\
#            [83,64,21],\
#            [73,103,36],\
#	    [110,99,27]\
#          ]
#radiuses = [90,19,23,13]
#colors = [190,130,160,90]
#centers = [ 
#	    [110,110,0],\
#            [110,90,20],\
#            [110,130,20],\
#	    [90,110,20],\
#    	    [130,110,20]\
#          ]
#radiuses = [50,15,15,1.5,1.5]
#colors = [190,130,160,90,60]
#
## same order as colors with 0 at the first position
#velocities = [1483, 1487, 1510, 1548, 1510, 1584]
#attenuations = [0,0,0,0,0.5,0.7]
#echogenities = [0,1,0.2,0.25,0.2,0.25]
#velocities = [1483, 1493, 1550, 1568, 1584]
#attenuations = [0,0,0,0.5,0.7]
#echogenities = [0,0,0,0,0.5]

centers = [ 
           [110,110,0],\
            [110,90,20],\
            [110,130,20],\
           [90,110,20],\
           [130,110,20]\
          ]
radiuses = [50,10,10,5,5]
colors = [190,130,160,90,60]
# same order as colors with 0 at the first position
velocities = [1483, 1450, 1510, 1548, 1510, 1584]
attenuations = [0,0.7,0.7,0.7,0.7,0.7]
echogenities = [0,1,0.2,0.25,0.2,0.25]


#centers = []
#radiuses = []
#colors = []
#velocities = [1483]
#attenuations = [0]
#echogenities = [0]

print "Bottom: "+str(bottom)
print "top: "+str(top)
print "slices: "+str(slices)
print "canvasSize: "+str(canvasSize)
print "resolution: "+str(resolution)
print "centers: "+str(centers)
print "radiuses: "+str(radiuses)
print "colors: "+str(colors)
print "Vertical resolution: " + str(verticalResolution) + "px"

sio.savemat('slicesParams.mat', {'attenuations':attenuations,'echogenities':echogenities,'velocities':velocities ,'colors':[0]+colors, 'height':[height], 'width':[canvasSize]})
for slice in range(slices):
  filename = "slice_%03d" % slice
  f = open(filename+".svg",'w')

  f.write('<?xml version="1.0" standalone="no"?>\n')
  f.write( '<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN"\n')
  f.write( '"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">\n')
  f.write( '<svg width="'+str(canvasSize)+'" height="'+str(canvasSize)+'" version="1.1" xmlns="http://www.w3.org/2000/svg">\n')

  for i in range(len(centers)):
    zr = abs( zdelta * slice - centers[i][2])
    if(zr >= radiuses[i]): continue
    radius = math.sqrt(pow(radiuses[i],2)-pow(zr,2))
    f.write( '<circle cx="%f" cy="%f" r="%f" style="fill:rgb(%d,%d,%d);stroke:rgb(%d,%d,%d);stroke-width:1"/>\n' % (centers[i][0], centers[i][1], radius, colors[i], colors[i], colors[i], colors[i], colors[i], colors[i] ))
  f.write( '</svg>\n')
  f.close()
  os.system("mogrify -format bmp3 -background black +antialias -density "+str(density)+" -depth 8 -type grayscale  msvg:"+filename+".svg")
  os.system("mv "+filename+".bmp3 "+filename+".bmp")
