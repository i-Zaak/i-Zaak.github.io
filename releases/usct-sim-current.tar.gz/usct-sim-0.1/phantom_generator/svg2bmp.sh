#!/bin/bash
mogrify -format bmp3 -background black +antialias -density 205 -depth 8 -type grayscale  msvg:*.svg
