function plotGeometry(filePath)
% Description: Plots transducer positions with associated normals
%
% Input: filePath -- path to file containing transducer 3D coordinates and
%        normals. Expects cartesian coordinates. The file has to contain
%        MxNx3 arrays 'elementPositions' and 'normals'.

f=load(filePath);
elems = f.elementPositions;
normals = f.normals;

n = size(elems,1);

C = squeeze(elems(1,:,:));

if(n > 1)
    for i=2:n
        B = squeeze(elems(i,:,:));
        C = vertcat(C,B);
    end
end

N = squeeze(normals(1,:,:));

if(n > 1)
    for i=2:n
        B = squeeze(normals(i,:,:));
        N = vertcat(N,B);
    end
end

N = C+ N.*0.01; %FIXME scale according to contents of elementPosition 

figure
hold on

scatter3(C(:,1),C(:,2),C(:,3))

for i=1:size(C,1)
    line([C(i,1) N(i,1)], [C(i,2) N(i,2)] ,[C(i,3) N(i,3)])
end
hold off