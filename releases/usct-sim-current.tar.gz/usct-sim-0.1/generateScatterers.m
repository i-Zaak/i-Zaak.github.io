function [ ] = generateScatterers( n, expParamsPath, volumePath, resultDir)
% inputs: n                 number of scatterers
%         expParamsPath     path to expParamsPath.mat
%         voxelModelPath    path to voxelModel.mat
%         resultDir         directory to store the scatterers.mat

voxelModel = load([volumePath '/voxelModel.mat']);
param = load( [expParamsPath '/expParams.mat']);

[extrem pixelSize] = computeExtrem(param.geometryEnvelope, voxelModel);
[vX vY vZ] = size(voxelModel.voxelMatrix);
ng = 1;

if(n >0)    
    scatterers = zeros(n,4);
    assert(any(any(any(voxelModel.voxelMatrix > 1))), 'ERROR - All voxels are water, which cannot contain scatterers.');

    while ng <= n
        xR = rand(1);
        yR = rand(1);
        zR = rand(1);

        voxelX = ceil(vX*xR);
        voxelY = ceil(vY*yR);
        voxelZ = ceil(vZ*zR);
        
        voxelType = voxelModel.voxelMatrix(voxelX,voxelY,voxelZ);
        
        if( voxelType > 1 ) % FIXME is water always 1???
            sx = extrem(1,1) + xR*(extrem(1,2) - extrem(1,1));
            sy = extrem(2,1) + yR*(extrem(2,2) - extrem(2,1));
            sz = extrem(3,1) + zR*(extrem(3,2) - extrem(3,1));
            
            echogVariance = voxelModel.volumeParams(voxelType,3); % 3 is magic number for echogenity coefficient; see volumePreprocess
            echogenity = randn()*sqrt(echogVariance);
            scatterers(ng,:) = [sx sy sz echogenity];
            ng = ng+1;
        end
    end
else
    scatterers = [];
end
save([resultDir '/scatterers.mat'], 'scatterers')
