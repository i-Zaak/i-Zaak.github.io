function [ P N_spect ] = simplePulse(fs,f0)
N_spect = 128;
T = 1/fs;
NP = 32;
t=(0:NP-1)*T;
pulse = cos(f0*2*pi*t') .* gausswin(NP);
P = fft(pulse,N_spect);
end

