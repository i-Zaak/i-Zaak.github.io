function [ voxelMatrix ] = generate3DFromSlices( slices, step, colorToAttributes)
% Generates volumetrical data based on given slices
% Each voxel has color, speed of sound and attenuation (x*y*z*3 matrix)
% Given n slices, the result has z dimension of (n-1)*(step+1)+1 and x and y 
% equal to the x and z dimension of slices


X = size(slices,1);
Y = size(slices,2);
n = size(slices,3);
Z = (n-1)*(step+1)+1;
Attributes = 3; % attributes (speed, echo, etc) + color HARDCODED! needs refactoring for echo

voxelMatrix = zeros(X,Y,Z,Attributes);

for s=1:(n-1)
    voxelMatrix(:,:,s+(step)*(s-1)) = slices(:,:,s);
end
voxelMatrix(:,:,(step+1)*(n-1)+1) = slices(:,:,n);

attribTable = zeros(256,2);
for i = 1:length(colorToAttributes.map_mat)
    attribTable(colorToAttributes.map_mat(i)+1,1) = colorToAttributes.map_vel(i);
    attribTable(colorToAttributes.map_mat(i)+1,2) = colorToAttributes.map_att(i);
end

for sliceId = 1:n-1
    bottomSliceId=(sliceId-1)*step + sliceId;
    upperSliceId = bottomSliceId + step + 1;
    for layer=bottomSliceId+1:upperSliceId-1
        for i=1:X
            for j=1:Y
                if( layer <= bottomSliceId+step/2)
                    color = voxelMatrix(i,j,bottomSliceId);                    
                else
                    color = voxelMatrix(i,j,upperSliceId);
                end
                
                % Only speed and attenuation considered, modify for echo if
                % needed
                %colorIndex = find(colorToAttributes.map_mat==color);
                %speed =  colorToAttributes.map_vel(colorIndex);
                %att = colorToAttributes.map_att(colorIndex);
                %speed = attribTable(color+1, 1);
                %att = attribTable(color+1, 2);
                voxelMatrix(i,j,layer,1) = color;
                %voxelMatrix(i,j,layer,2) = speed;
                %voxelMatrix(i,j,layer,3) = att;
                
            end
        end
    end
end

for i=1:X
    for j=1:Y
        for k=1:Z
            color = voxelMatrix(i,j,k,1);
            speed = attribTable(color+1, 1);
            att = attribTable(color+1, 2);
            voxelMatrix(i,j,k,2) = speed;
            voxelMatrix(i,j,k,3) = att;
        end
    end
end



