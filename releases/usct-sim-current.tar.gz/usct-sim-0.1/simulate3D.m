function [ ] = simulate3D( handles, voxelModel, pixelSize )
% Wrapper function for main simulation. NEEDS MAJOR REFACTORING!
% DEPRECATED!!!!
    disp('Do NOT ever run this file -- instead, use processRays!!!!')
    Dir = get(handles.edit_adr, 'String');
    val = get(handles.list_map,'Value');
    str = get(handles.list_map, 'String');
    
    parametry_name = [Dir,'/parameters.mat'];
    param = load(parametry_name);
    modelSize = size(voxelModel(:,:,:,1));
    
    statsDataRoot ='/data/usct_data/noise_amplitude_stats2';
    

    profile on
    
    N_spect = param.vzorkovaci_spektrum; N_spect = str2num(N_spect);
    fs = param.vzorkovaci_frekvence; fs = str2num(fs);fs=fs*10e5;   % [Hz] (sampling freq.)
    T = 1/fs;   % [s] (sampling period)
    f0 = param.Stredni_frekvence; f0 = str2num(f0);f0=f0*10e5;  % [Hz] (pulse freq.)
    nn = param.nn; nn = str2num(nn);
    radius2 = param.radius; radius2 = str2num(radius2);
    c = 1498;  % [m/s]
    diameterCylinder = radius2;
    radius = radius2 / 2;
    ztop = param.ztop; ztop = str2num(ztop);   % [m] vrchni cast fantomu
    zbottom = param.zbottom; zbottom = str2num(zbottom);    % [m] spodni cast fantomu
    savePath = param.cesta_ulozeni;
    

    %%  modeled sent pulse (ideal)
    NP = 32;
    t=(0:NP-1)*T;
    pulse = cos(f0*2*pi*t') .* gausswin(NP);
    P = fft(pulse,N_spect);
    P0 = P;
    % figure(1);plot(pulse);pause;
    %return

    % frequency
    f = [(0:N_spect/2-1) (-N_spect/2:-1)]';
    f = f * fs / N_spect;

    model_name = 'mereni_3D'
    % map_att = zeros(size(map_att)); %%%%%%%%%%%%%%%%%%%%%%%%%%%%!!!!!!!!!!!!!!!!!!!
    % model_name = 'mereni_3D_prazdne'
    out_dir = [model_name];
    realAdr = cd ();


    %%  ziskani souradnic 3D modelu
    set(0,'userdata',diameterCylinder);
    create3DDemonstratorGeometry_model

    %FIXME
    %S=load([Dir '/coordinates/GeometryNormalsDiam0_18407_sender.mat']);
    %R=load([Dir '/coordinates/GeometryNormalsDiam0_18407_receiver.mat']);
    S=load([Dir '/coordinates/GeometryNormalsDiam0_18407_sender.mat']);
    R=load([Dir '/coordinates/GeometryNormalsDiam0_18407_receiver.mat']);
    %S = S.elementPositions;    
    %R = R.elementPositions;
    
    minX = min(min(R.elementPositions(:,:,1)));
    maxX = max(max(R.elementPositions(:,:,1)));
    minY = min(min(R.elementPositions(:,:,2)));
    maxY = max(max(R.elementPositions(:,:,2)));
    minZ = min(min(R.elementPositions(:,:,3)));
    maxZ = max(max(R.elementPositions(:,:,3)));
    
    pixelSize = (maxX-minX)/(modelSize(1)-2); % predpoklada ctvercove obrazky. FIXME validace! 
    
    extrem = zeros(3,2);
    extrem(1,1)=minX - 1*pixelSize;
    extrem(2,1)=minY - 1*pixelSize;
    extrem(3,1)=minZ - 1*pixelSize;
    %extrem(:,2)=modelSize;
    extrem(1,2)=maxX + 1*pixelSize;
    extrem(2,2)=maxY + 1*pixelSize;
    extrem(3,2)=minZ + modelSize(3)*pixelSize + 1;
    
    extrem(:,1) = extrem(:,1) + 0.1;
    extrem(:,2) = extrem(:,2) + 0.1;
    
    
    sl_range = get (handles.sl_rangeEE,'string');
    rl_range = get(handles.rl_rangeEE,'string');
    AScansLength = 3500;
    for layerSender = (eval(sl_range)-1) %0:4 ;%12; %FIXME interval??    
        layer_dir = [savePath sprintf('/layerSender_%04d',layerSender)];
        mkdir(layer_dir);
        for senderNumber = 0:95  %pocet vysilacich prvku pri toceni motoru %FIXME interval?!
            motor_pos = mod(senderNumber, 6); % od 0 do 5
            sender_dir = [layer_dir sprintf('/senderNumber_%04d',senderNumber)];
            mkdir(sender_dir);
            %disp(sprintf('layerSender:%04d senderNumber:%04d',layerSender,senderNumber))

            AScans = zeros(AScansLength,length(eval(rl_range))*32);
            Map = zeros (3,48*192);
            ascan = 0;         
            
            LayerS = 1+(layerSender);       % vrstva vysilace 0:23
            NumberS = 1+(senderNumber);     % cislo vysilace 0:95
            
            %FIXME
            %coordSender = getCoordinates(S,'cartesian',LayerS,NumberS);
            coordSender = getCoordinates(S,'cartesian',LayerS,NumberS) + 0.1; %FIXME EVIL HACK!!!
            %coordSender = squeeze(S(LayerS,NumberS,:))' + 0.1;
            
            
            for layerReceiver = (eval(rl_range)-1) %0:7 %0:19 %24:25 %FIXME interval!?                
                 NumberR =  motor_pos*2 + 1; % pocatecni receiver element
                 delta_nr = 1; % prirustek pro inkrementaci NumberR v dalsim kroku (strida se 1 a 11)
                 %!!!
                 %%%for receiverindex = 0:5 %FIXME inteval!?
                 for receiverindex = 0:31 %%%RRR160710 opraven rozsah
                    ascan = ascan + 1;
                    LayerR = 1+(layerReceiver);     % vrstva prijimace 0:47
                    
                    %FIXME
                    coordReceiver = getCoordinates(R,'cartesian',LayerR,NumberR)+ 0.1; %FIXME EVIL HACK!!!
                    %coordReceiver = squeeze(R(LayerR,NumberR,:))'+ 0.1; %FIXME EVIL HACK!!!                    
                    %A = squeeze(coordSender);                    
                    %B = squeeze(coordReceiver);
                    %xdeb(1) = A(1);
                    %xdeb(2) = B(1);
                    %ydeb(1) = A(2);
                    %ydeb(2) = B(2);                    
                    %plot(xdeb, ydeb);hold on;
                    
                    
                    
                    [betad time rayLength] = simulate3DRay( voxelModel, pixelSize, coordSender, coordReceiver, extrem);
                    %P = P0 .* exp(-betad.* (abs(f).^nn) );   %nelinearni zavislost f na beta
                    %p = real(ifft(P));
                    %pos = round(time/T);
		    % FIXME - compute P0 based on angle dependent freq. response
                    [p pos] = computePulse(betad, time, P0, f, nn, T);
                    AScans((1+pos):(pos+N_spect),ascan) = AScans((1+pos):(pos+N_spect),ascan) + p/rayLength^2; % FIXME move the distance scaling to the computePulse function
                    %reflectorsCoords = [0.19;0.1;0.012]+0.1;% FIXME - jen na zkousku
                    %for coordReflector = reflectorsCoords
                    %    [betad1 time1 rayLength1] = simulate3DRay( voxelModel, pixelSize, coordSender, coordReflector, extrem);
                    %    [betad2 time2 rayLength2] = simulate3DRay( voxelModel, pixelSize, coordReflector, coordReceiver, extrem);
                    %    betadRef = betad1 + betad2;
                    %    timeRef = time1 + time2;
                    %    
                    %    
                    %    [pRef posRef] = computePulse(betadRef, timeRef, P0, f, nn, T);
                    %    pRef = pRef * getReflectionCoefficient(voxelModel, pixelSize, coordReflector);
                    %    pRef = pRef/(rayLength1^2 * rayLength2^2);
                    %    AScans((1+posRef):(posRef+N_spect),ascan) = AScans((1+posRef):(posRef+N_spect),ascan) + pRef;
                    %end
                    
                    statsFile = [statsDataRoot '/layerSender_'  sprintf('%04d', layerSender)  '/senderNumber_'  sprintf('%04d', senderNumber) '/stats.mat' ];
                    s = load(statsFile, 'stats');
                    stats = s.stats;
                    noisePosition = 0;
                    for i=1:size(stats,2)
                        if(stats(1,i) == layerReceiver && stats(2,i) == NumberR - 1)
                            noisePosition = i;
                        end
                    end
                    noise_std = stats(4,noisePosition);
                    amplitude = stats(5,noisePosition)/2;
                    %noise_std = stats(ascan,1);
                    %amplitude = stats(ascan,2);
                    
                    AScans(:,ascan) = AScans(:,ascan) * (amplitude/(2*max(abs(AScans(:,ascan)))));
                    
                    noise_max = noise_std*2;
                    noise_min = - noise_max;
                    noise = noise_max - (noise_max-noise_min).*rand(AScansLength,1);
                    AScans(:,ascan) = AScans(:,ascan) + noise;
                    
                    %%%RRR160710 TEST:
                    
                    %testl = sqrt((coordSender(1)-coordReceiver(1))^2+(coordSender(2)-coordReceiver(2))^2+(coordSender(3)-coordReceiver(3))^2);
                    %rayLength;                    
                    %timec = testl / 1483;
                    %testp = round( testl / 1483 /T);
                    %assert(abs(rayLength-testl)/rayLength < 0.000001  && abs(timec -time)/time < 0.000001 );
                    %figure(10); 
                    %subplot(2,1,1); plot(AScans((1+testp):(testp+N_spect),ascan) / max(AScans((1+testp):(testp+N_spect),ascan)))
                    %subplot(2,1,2); plot(p)
                    %pause
                    
                    Map(1, ascan) = layerReceiver;
                    Map(2, ascan) = NumberR - 1;  %receiverNumber;
                    NumberR = NumberR + delta_nr;
                    if delta_nr==1
                        delta_nr = 11;
                    else
                        delta_nr = 1;
                    end
                 end
            end
            AScans = AScans(:,1:ascan);
            Map = Map(:,1:ascan);
            save([sender_dir '/data'], 'AScans', 'Map');
        end
    end
    profile viewer
end

