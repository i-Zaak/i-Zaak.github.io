function PNew = modifyPulse(POld, senderCoord, receiverCoord, senderNormal, radiationFunction,a , c, fs, NN)
% determines the angle dependent radiation coefficient. 

rayDir = receiverCoord - senderCoord;

theta = acos(dot(senderNormal,rayDir)/(norm(senderNormal)*norm(rayDir))); % radians
theta = radtodeg(theta); %degrees
%disp(['theta ' int2str(theta)])

radFun =  eval(['@' radiationFunction]);

[D,f] = radFun(a, c, theta, fs, NN);
PNew = POld .* D';
