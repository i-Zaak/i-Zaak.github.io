    function [ ] = processRays( paramPath, voxelModel, coordinates, scatterers, savePath, cachePath)
% Processes list of sender/receiver combinations producing single data file
% with resulting ascans.
%
% param is a structure containing all necessary simulation parameters:
%  pixelSize - size of voxel from the voxelModel in real world [m]
%  extrem - matrix with the smallest and largest coordinates of the model
%         in format extrem(1,1)=minX extrem(2,1)=minY extrem(3,1)=minZ 
%         extrem(1,2)=maxX extrem(2,2)=maxY extrem(3,2)=maxZ
%  N_spect - sampling spectrum FIXME units
%  fs - sampling frequency FIXME units
%  f0 - pulse frequency FIXME units
%  P - modeled sent pulse
%  nn - FIXME what is this?
%
% voxelModel is a four dimensional matrix representing the 3D volume under
%  simulation. The values describing the enviroment are placed following
%  way: voxelModel(:,:,1) - color of input image, voxelModel(:,:,2) - 
%  speeed of sound, voxelModel(:,:,3) - attenuation coefficient
%
% coordinates list of sender/receiver positions and noise information.
%  Data in one row are ordered:
%   senderX senderY senderZ receiverX receiverY receiverZ senderNormalX ...
%   ... senderNormalY senderNormalZ noiseStd noiseAmp
%
%   (noiseStd is the standart deviation of the noise, amplitude is the
%   maximal amplitude for the particular sender/receiver combination)
%
% scatterers is a list of coordinates of points able to reflect the usct
%  waves. For every combination of sender and receiver an additional path 
%  for every reflector is taken and added to the resulting AScan. 
%  format: X Y Z
%
% Resulting AScans for all given coordinates combinations are stored in the
% savePath directory in one data.mat file in the int16 format.
tic
param = load(paramPath);

N_spect = param.N_spect;
fs = param.fs;
T = 1/fs;   % [s] (sampling period)
%f0 = param.f0;
nn = param.nn;
a = param.a; %[m]
c = param.c;  % [m/s]
P0 = param.P;

% frequency
f = [(0:N_spect/2-1) (-N_spect/2:-1)]';
f = f * fs / N_spect; 

% radiation characteristic 
radiationFunction = param.rad_fun;


[extrem pixelSize] = computeExtrem(param.geometryEnvelope, voxelModel);
    AScansLength = 3500;
    %store the experiment parameters
    AScans = zeros(AScansLength,size(coordinates,1));
    senders = coordinates(:,1:3);
    receivers = coordinates(:,4:6);
    senderNormals = coordinates(:,7:9);
    receiverNormals = coordinates(:,10:12);
    cache_file=0;
    keyS = '';
    keyR = '';
    addpath('cache');
    for i=1:size(coordinates,1)
        AScan = zeros(AScansLength,1);

        coordSender = senders(i,:);
        coordReceiver = receivers(i,:);
        senderNormal = senderNormals(i,:);
        receiverNormal = receiverNormals(i,:);
        %ascan = 0;
        
        %ascan = ascan + 1;
        
        %noise_std = coordinates(i,13);
        %amplitude = coordinates(i,11); deprecated!
        if(~isempty(scatterers))
            keySn = sprintf('o%03.0fo%03.0fo%03.0f', round(coordSender.*1000));
            keyRn = sprintf('o%03.0fo%03.0fo%03.0f', round(coordReceiver.*1000));
            if ~strcmp(keyS,keySn)
                cacheStruct = load([cachePath '/' keySn]);
                betadsS = cacheStruct.betads;
                pulsesS = cacheStruct.pulses;
                rayLengthsS = cacheStruct.rayLengths;
                timesS = cacheStruct.times;
                keyS = keySn;
            end
            if ~strcmp(keyR, keyRn)
                cacheStruct = load([cachePath '/' keyRn]);
                betadsR = cacheStruct.betads;
                pulsesR = cacheStruct.pulses;
                rayLengthsR = cacheStruct.rayLengths;
                timesR = cacheStruct.times;
                keyR = keyRn;
            end
        end
        
        PDirect = modifyPulse(P0, coordSender, coordReceiver, senderNormal, radiationFunction,a , c, fs, N_spect);
        %PDirect0 = PDirect;
        PDirect = modifyPulse(PDirect, coordReceiver, coordSender,  receiverNormal, radiationFunction,a , c, fs, N_spect);
        %PDirect1 = PDirect;
        %PDirect = PDirect1.*PDirect2;
        [betad time rayLength] = simulate3DRay( voxelModel, pixelSize, coordSender, coordReceiver, extrem);        
        
        [p pos] = computePulse(betad, time, PDirect, f, nn, T);
        p( length(p)/2+1 : end) = 0; %FIXME evil warkaround!!
        %save([savePath '/pulse_' int2str(i)], 'PDirect0','PDirect1', 'p');   
        AScan((1+pos):(pos+N_spect)) = AScan((1+pos):(pos+N_spect)) + p/rayLength;
        %AScans((1+pos):(pos+N_spect),i) = AScans((1+pos):(pos+N_spect),i) + p/rayLength;
        
        %AScans(:,ascan) = AScans(:,ascan)*(amplitude/(2*max(abs(AScans(:,ascan))))); deprecated!
        %if exist([cachePath '/load_cache'],'file')
        %    cache_miss = 0;
        %    save([savePath '/tmp_cache'], 'cache');
        %    movefile([savePath '/tmp_cache'], [savePath '/cache_' int2str(cache_file)]);
        %    cache_file = cache_file + 1;
        %
        %    load([savePath '/merged_cache'])
        %    delete([savePath '/load_cache'])                    
        %end
        for j=1:size(scatterers,1)
            coordReflector = scatterers(j,1:3); % see generateScatterers
            echogenity = scatterers(j,4); % see generateScatterers
            time1 = timesS(j);
            betad1 = betadsS(j);
            rayLength1 = rayLengthsS(j);
            PReflected1 = pulsesS(:,j);
            %PReflected1 = modifyPulse(P0, coordSender, coordReflector, senderNormal, radiationFunction,a , c, fs, N_spect);
            time2 = timesR(j);
            betad2 = betadsR(j);
            rayLength2 = rayLengthsR(j);
            PReflected2 = pulsesR(:,j);
            %PReflected2 = modifyPulse(P0, coordReceiver, coordReflector, receiverNormal, radiationFunction,a , c, fs, N_spect);
            
            PReflected = PReflected1 .* PReflected2;
            
            betadRef = betad1 + betad2;
            timeRef = time1 + time2;            
            
            [pRef posRef] = computePulse(betadRef, timeRef, PReflected, f, nn, T);
            
            %pRef = pRef * getReflectionCoefficient(voxelModel, pixelSize, coordReflector);
            pRef = pRef .* echogenity.*0.00001;
            pRef = pRef./(rayLength1 * rayLength2);
            AScan((1+posRef):(posRef+N_spect)) = AScan((1+posRef):(posRef+N_spect)) + pRef;
            
            %AScans((1+posRef):(posRef+N_spect),i) = AScans((1+posRef):(posRef+N_spect),i) + pRef;
            
        end
        % FIXME create dedicated post-processing script
        %noise_max = noise_std*2;
        %noise_min = - noise_max;
        %noise = noise_max - (noise_max-noise_min).*rand(AScansLength,1);
        %AScans(:,ascan) = AScans(:,ascan) + noise;
        %AScans = AScans(:,1:ascan);
        AScans(:,i) = AScan;
    end    
    AScans = AScans.*10000;
    AScans = int16(AScans);
    %save([savePath '/tmp_cache'], 'cache');
    %movefile([savePath '/tmp_cache.mat'], [savePath '/cache_' int2str(cache_file) '.mat']);    
    save([savePath '/data'], 'AScans');   
    toc
end

