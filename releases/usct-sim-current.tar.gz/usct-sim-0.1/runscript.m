% example runscript, place other in the runscripts folder

volumePath = '/home/izaak/Forge/usct_simulation/phantoms/fantom_new_slices';
resultsPath = '/mnt/data/izaak/usct_simulated_data/exp1';
senderPath = '/home/izaak/Forge/usct_simulation/geometries/kruhe_mk1/GeometryNormalsDiam0_18407_sender.mat';
receiverPath = '/home/izaak/Forge/usct_simulation/geometries/kruhe_mk1/GeometryNormalsDiam0_18407_receiver.mat';
statsDataRoot = '/mnt/data/izaak/usct_simulated_data/noise_amplitude_stats2/';
reflectorsPath = resultsPath;
coordinatesPath = '';

mkdir(resultsPath);

senderLayers = [1 1]; %must be a vector of length 2 -- [firstLayer lastLayer]
receiverLayers = [1 1]; %same here

% uncomment to generate voxelModel
% volumePreprocess(volumePath);

volumeParams = load([volumePath '/slicesParams.mat']);
voxelModel = load([volumePath '/voxelModel.mat']);

expParamsPath = generateExpParams(resultsPath);

coordinatesPaths = raysPreprocess( senderPath, receiverPath, expParamsPath, senderLayers, receiverLayers, statsDataRoot, resultsPath);
save([resultsPath '/coordinatesPaths.mat'], 'coordinatesPaths');

generateScatterers(10, resultsPath, volumePath, resultsPath )
sc = load( [reflectorsPath '/scatterers.mat']);

for i=1:size(coordinatesPaths,1)
    c= load([coordinatesPaths(i,:) '/raysCoordinates.mat']);
    coordinates =  c.coordinates;
    processRays( expParamsPath, voxelModel, coordinates, sc.scatterers, coordinatesPaths(i,:) );

end


disp('Done.')
