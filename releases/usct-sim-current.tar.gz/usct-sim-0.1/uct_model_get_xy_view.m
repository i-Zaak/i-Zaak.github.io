X = XA; Y = YA;     %prirazeni velikosti obrazku

vektorB=[];
vektorV=[];

% line coefficients:
aa1 = (y1-y2)/(x1-x2);
bb1 = y1 - aa1*x1;      %rovnice primky

ix1 = round(x1*X/radius/2 + X/2 + 0.5);
ix2 = round(x2*X/radius/2 + X/2 + 0.5);
iy1 = round(y1*Y/radius/2 + Y/2 + 0.5);
iy2 = round(y2*Y/radius/2 + Y/2 + 0.5);

izt = round((ztop - min([z1 z2]))* konstSample + 1);
izb = round((zbottom - min([z1 z2]))* konstSample + 1);
% count
count = 0;
betad = 0;
tcel = 0;

if (abs(aa1)<1)     % urceni sklonu primky..jake koeficienty se budou pocitat
	mi = min(ix1,ix2);
	MA = max(ix1,ix2);
    if ix1 > ix2
        zz = z1; z1=z2; z2=zz;
    end
	for iix = mi:MA;
		x = (iix-X/2 - 0.5)*2*radius/X;
		y = aa1*x + bb1;
		iiy = round(y*Y/radius/2 + Y/2 + 0.5);
       
        if ((iiy>0)&&(iiy<=Y)&&(iix<=X)&&(iix>0))
			vektorB = [vektorB map_att(iiy,iix)];
            count = count + 1;
        end
        resultB_xy = repmat(vektorB,vrstev,1);
        
        if ((iiy>0)&&(iiy<=Y)&&(iix<=X)&&(iix>0))
            vcel = map_vel(iiy,iix);
            vektorV = [vektorV vcel];
        end      
        resultV_xy = repmat (vektorV,vrstev,1);
        
    end
else
	mi = min(iy1,iy2);
	MA = max(iy1,iy2);
    if iy1 > iy2
        zz = z1; z1=z2; z2=zz;
    end
	for iiy = mi:MA
		y = (iiy-Y/2 - 0.5)*2*radius/Y;
		x = (y - bb1)/aa1;
		iix = round(x*X/radius/2 + X/2 + 0.5);
		   
        if ((iix>0)&&(iix<=X)&&(iiy<=Y)&&(iiy>0))
            vektorB = [vektorB map_att(iiy,iix)];
			count = count + 1;
        end
        resultB_xy = repmat(vektorB,vrstev,1);
        
        if ((iix>0)&&(iix<=X)&&(iiy<=Y)&&(iiy>0))
            vcel = map_vel(iiy,iix);
            vektorV = [vektorV vcel];
        end
        resultV_xy = repmat (vektorV,vrstev,1);
	end
end

if izt < 1
    
elseif izt >= vrstev
    resultB_xy (:,:)= 0;
    resultV_xy (:,:)= 1483;
else 
    resultB_xy (1:izt,:) = 0;
    resultV_xy (1:izt,:) = 1483;
end

if izb < 1
    resultB_xy (:,:) = 0;
    resultV_xy (:,:)= 1483;
elseif izb >= vrstev
else
    resultB_xy (izb:end,:) = 0;
    resultV_xy (izb:end,:) = 1483;
end

