function [ coordinatesPaths] = raysPreprocess( senderPath, receiverPath, expParamsPath, senderLayers, receiverLayers, statsDataRoot, savePath )
% prepares the inputs for the simulation for the Kruhe USCT mk.1
%
% input parameters:
%       senderPath      path to geometry file with senders
%       receiverPath    path to geometry file with receivers
%       expParamsPath   configuration file of the simulation
%       senderLayers    vector of length 2 -- [firstLayer lastLayer]
%       receiverLayers  vector of length 2 -- [firstLayer lastLayer]
%       statsDataRoot   path to noise statistics
%       savePath        results will be written here

senders=load(senderPath);
receivers=load(receiverPath);

assert(size(senderLayers,2)==2 && senderLayers(1) <= senderLayers(2),'ERROR specify sender layers as matrix [from to].') ;
assert(size(receiverLayers,2)==2 && receiverLayers(1) <= receiverLayers(2),'ERROR specify sender layers as matrix [from to].') ;
assert(senderLayers(1) > 0 && senderLayers(1) <= size(senders.elementPositions,1), 'ERROR sender layers are out of range.');
assert(senderLayers(2) > 0 && senderLayers(2) <= size(senders.elementPositions,1), 'ERROR sender layers are out of range.');
assert(receiverLayers(1) > 0 && receiverLayers(1) <= size(receivers.elementPositions,1), 'ERROR receiver layers are out of range.');
assert(receiverLayers(2) > 0 && receiverLayers(2) <= size(receivers.elementPositions,1), 'ERROR receiver layers are out of range.');


minX = min(min(min(receivers.elementPositions(:,:,1))),min(min(senders.elementPositions(:,:,1))));
maxX = max(max(max(receivers.elementPositions(:,:,1))),max(max(senders.elementPositions(:,:,1))));
minY = min(min(min(receivers.elementPositions(:,:,2))),min(min(senders.elementPositions(:,:,2))));
maxY = max(max(max(receivers.elementPositions(:,:,2))),max(max(senders.elementPositions(:,:,2))));
minZ = min(min(min(receivers.elementPositions(:,:,3))),min(min(senders.elementPositions(:,:,3))));
maxZ = max(max(max(receivers.elementPositions(:,:,3))),max(max(senders.elementPositions(:,:,3))));

% translation into  positive values
tX = 0;
tY = 0;
tZ = 0;
if minX < 0
    tX = abs(minX);  
    receivers.elementPositions(:,:,1) = receivers.elementPositions(:,:,1) + tX;
    senders.elementPositions(:,:,1) = senders.elementPositions(:,:,1) + tX;
    minX = 0;
    maxX = maxX+tX;
end
if minY < 0
    tY = abs(minY);
    receivers.elementPositions(:,:,2) = receivers.elementPositions(:,:,2) + tY;
    senders.elementPositions(:,:,2) = senders.elementPositions(:,:,2) + tY;
    minY = 0;
    maxY = maxY+tY;
end
if minZ < 0
    tZ = abs(minZ);
    receivers.elementPositions(:,:,3) = receivers.elementPositions(:,:,3) + tZ;
    senders.elementPositions(:,:,3) = senders.elementPositions(:,:,3) + tZ;
    minZ = 0;
    maxZ = maxZ+tZ;
end

geometryEnvelope = [minX maxX; minY maxY; minZ maxZ];
translation = [tX tY tZ ];

save(expParamsPath, '-append', 'geometryEnvelope', 'translation', 'senderLayers', 'receiverLayers');

 
coordinatesPaths = [];
allCoords = single(zeros((senderLayers(2) -senderLayers(1) +1 ) * 96 + (senderLayers(2) -senderLayers(1) +1 ) * 96*(receiverLayers(2)-receiverLayers(1) +1) * 32, 3));
disp('before')
size(allCoords)
allNormals = single(zeros((senderLayers(2) -senderLayers(1) +1 ) * 96 + (senderLayers(2) -senderLayers(1) +1 ) * 96 *(receiverLayers(2)-receiverLayers(1) +1) * 32, 3));
k=1;
for layerSender = (senderLayers(1):senderLayers(2))
    layer_dir = [savePath sprintf('/layerSender_%04d',layerSender-1)];
    mkdir(layer_dir);
    for senderNumber = 0:95  %pocet vysilacich prvku pri toceni motoru
        motor_pos = mod(senderNumber, 6); % od 0 do 5
        sender_dir = [layer_dir sprintf('/senderNumber_%04d',senderNumber)];
        mkdir(sender_dir);

        
        Map = zeros (3,48*192);
        ascan = 0;         
        coordinates = [];
        
        coordSender = getCoordinates(senders,'cartesian',layerSender,senderNumber+1);
        senderNormal = getNormal(senders,'cartesian',layerSender, senderNumber+1);
        
        allCoords(k,:) = squeeze(coordSender)';
        allNormals(k,:) = squeeze(senderNormal)';
        k = k+1;
       
        for layerReceiver = (receiverLayers(1):receiverLayers(2)) 
            NumberR =  motor_pos*2 + 1; % pocatecni receiver element
            delta_nr = 1; % prirustek pro inkrementaci NumberR v dalsim kroku (strida se 1 a 11)
            
            for receiverindex = 0:31 %%%RRR160710 correct range
                ascan = ascan + 1;
                
                coordReceiver = getCoordinates(receivers,'cartesian',layerReceiver,NumberR);
                receiverNormal = getNormal(receivers,'cartesian',layerReceiver,NumberR);  
                %statsFile = [statsDataRoot '/layerSender_'  sprintf('%04d', layerSender-1)  '/senderNumber_'  sprintf('%04d', senderNumber) '/stats.mat' ];
                %s = load(statsFile, 'stats'); % FIXME configuration file?
                %stats = s.stats;
                %noisePosition = 0;
                %% FIXME invariant -- read first and transform to some reasonable structure
                %for i=1:size(stats,2)
                %    if(stats(1,i) == layerReceiver && stats(2,i) == NumberR - 1)
                %        noisePosition = i;
                %    end
                %end
                %noise_std = stats(4,noisePosition);
                %amplitude = stats(5,noisePosition)/2;
                
                %coordinates =[coordinates; squeeze(coordSender)' squeeze(coordReceiver)' squeeze(senderNormal)' squeeze(receiverNormal)' noise_std amplitude];
                coordinates =[coordinates; squeeze(coordSender)' squeeze(coordReceiver)' squeeze(senderNormal)' squeeze(receiverNormal)'];
                allCoords(k,:) = squeeze(coordReceiver)';
                allNormals(k,:) = squeeze(receiverNormal)';
                k = k+1;
                Map(1, ascan) = layerReceiver - 1;
                Map(2, ascan) = NumberR - 1;  %receiverNumber;
                NumberR = NumberR + delta_nr;
                if delta_nr==1
                    delta_nr = 11;
                else
                    delta_nr = 1;
                end
            end
        end
        Map = Map(:,1:ascan);
        save([sender_dir '/map'], 'Map');
        save([sender_dir '/raysCoordinates.mat'], 'coordinates');
        coordinatesPaths = [coordinatesPaths; sender_dir ];
    end
end
disp('before')
size(allCoords)
[allCoords i j] = unique(allCoords, 'rows');
allNormals = allNormals(i,:);
save([savePath '/allEmitters'], 'allCoords', 'allNormals');
