% Computes accomulated attenuation and time for a ray sent throught a given
% model. 
% model		three dimensional array containing the material indexes 
%		representing heterogenous volume
% speedMap	mapping from material indexes to corresponding speed of sound
%		two dimensional array, each row represents one material
% betaMap	mapping from material indexes to corresponding attenuation
%		two dimensional array, each row represents one material
% pixelSize	length of one pixel in FIXME(jednotky)
% startPoint	coordinates of the source of the ray (1,3)
% endPoint	coordinates of the ending of the ray (1,3)
% 
function [ betad time rayLength ] = simulate3DRay( voxelModel, pixelSize, startPoint, endPoint, extrem)
%!assert(size(startPoint,1) == 1, 'wrong format of coordinates');
%!assert(size(startPoint,2) == 3, 'wrong format of coordinates');
%!assert(size(endPoint,1) == 1, 'wrong format of coordinates');
%!assert(size(endPoint,2) == 3, 'wrong format of coordinates');
%extrem = zeros(3,2);
%global voxels;
%extrem(:,1)=zeros(1,3);
%extrem(:,2)=modelSize;
%extrem(:,2) =extrem(:,2) *pixelSize
%disp('=================================================================')
steps(1)=pixelSize;
steps(2)=pixelSize;
steps(3)=pixelSize;

beamEnds = zeros(3,2);
beamEnds(:,1) = startPoint;
beamEnds(:,2) = endPoint;
%beamEnds=[ 0.01 0.01 0.01; 0.1 0.1 0.1 ]'
% =======================================================
vecX=extrem(1,1):steps(1):extrem(1,2);
vecY=extrem(2,1):steps(2):extrem(2,2);
vecZ=extrem(3,1):steps(3):extrem(3,2);


% ---------------
%!rect = zeros(4,2);
%!rect(1,:) = 0;
%!rect(2:3,1) = extrem(1,2);
%!rect(3:4,2) = extrem(2,2);
%!rect(4,1) = 0;
%!rect(2,2) = 0;
%line(rect(:,1),rect(:,2));
%--------------------------

%line(beamEnds(1,:), beamEnds(2,:), beamEnds(3,:), 'Color' , 'red', 'LineWidth',1)
%[gridX, gridY, gridZ]=meshgrid(vecX,vecY,vecZ);
numX=length(vecX);
numY=length(vecY);
numZ=length(vecZ);

beamVec = beamEnds(:,2) - beamEnds(:,1);

beamEq = [beamEnds(:,1) beamVec];


intCoors=zeros(numX+numY+numZ,3);

numInt=0;
intParam = zeros(length(vecX)+length(vecY)+length(vecZ),1);
%intType = zeros(length(vecX)+length(vecY)+length(vecZ),1);
if (beamEq(1,2) ~= 0.0)
	for i=1:length(vecX)
		linePar=(vecX(i) - beamEq(1,1))/beamEq(1,2);
		intPoint = beamEq(:,1) + beamEq(:,2)*linePar;
        if (intPoint(2) >= extrem(2,1) && intPoint(2) <= extrem(2,2) && intPoint(3) >=extrem(3,1) && intPoint(3) <=extrem(3,2)&& linePar>=0 && linePar <= 1)
			numInt=numInt+1;
			intCoors(numInt,:) = intPoint;
			intParam(numInt) = linePar;
			%intType(numInt) = 1;
        end        
	end
end

if (beamEq(2,2) ~= 0.0)	
	for i=1:length(vecY)
		linePar=(vecY(i) - beamEq(2,1))/beamEq(2,2);
		intPoint = beamEq(:,1) + beamEq(:,2)*linePar;
        if (intPoint(1) >= extrem(1,1) && intPoint(1) <= extrem(1,2) && intPoint(3) >= extrem(3,1) && intPoint(3) <= extrem(3,2)&& linePar>=0 && linePar <= 1)
			numInt=numInt+1;
			intCoors(numInt,:) = intPoint;
			intParam(numInt) = linePar;
			%intType(numInt) = 2;
        end 
	end
end

if (beamEq(3,2) ~= 0.0)	
	for i=1:length(vecZ)
		linePar=(vecZ(i) - beamEq(3,1))/beamEq(3,2);
		intPoint = beamEq(:,1) + beamEq(:,2)*linePar;
        if (intPoint(1) >= extrem(1,1) && intPoint(1) <= extrem(1,2) && intPoint(2) >= extrem(2,1) && intPoint(2) <= extrem(2,2)&& linePar>=0 && linePar <= 1)
			numInt=numInt+1;
			intCoors(numInt,:) = intPoint;
			intParam(numInt) = linePar;
			%intType(numInt) = 3;
        end 
	end
end

intParam_tmp = intParam(1:numInt);
%intType_tmp = intType(1:numInt);

intParam = intParam_tmp;
%intType = intType_tmp;

if(~exist('intParam','var'))
    error('Ray is outside of the model.')
     
else
[intParamSort,indsSort]=sort(intParam);
%![intParamUniq, indsUniq] = unique(intParamSort);
%!assert(size(intParamUniq,1) == size(intParamSort,1));
indsFinal = indsSort;
%!indsFinal = indsSort(indsUniq);
coorsFinal = [beamEnds(:,1)';intCoors(indsFinal,:);beamEnds(:,2)'];



%line(coorsFinal(:,1), coorsFinal(:,2),coorsFinal(:,3)); hold on;

%!len=0.0;
betad = 0;
timeOfTravel = 0;
numOfVoxels = size(coorsFinal,1) - 1;
voxel = zeros(2,3);
for vox=1:numOfVoxels
	pointIn = coorsFinal(vox,:);
	pointOut = coorsFinal(vox+1,:);
	pointAv=0.5*(pointIn+pointOut);
    for i=1:3
		voxel(1,i)=abs(floor((pointAv(i) - extrem(i,1))/steps(i))*steps(i) + extrem(i,1));
		voxel(2,i)=voxel(1,i) + steps(i);	
    end
    %voxel
    %extrem(:,1)
    %voxel(2,:)-extrem(:,1)'
    %!xr(1) = voxel(1,1);
    %!xr(2) = voxel(2,1);
    %!yr(1) = voxel(1,2);
    %!yr(2) = voxel(2,2);
    %plot(xr,yr);
	mapVoxel = ceil((voxel(2,:)-extrem(:,1)')./pixelSize);
	segmentLen = norm(pointOut-pointIn);    
	%!len=len+segmentLen;
	%FIXME nemelo by zaviset na delce segmentu??    
    voxelType = voxelModel.voxelMatrix(mapVoxel(1), mapVoxel(2),mapVoxel(3));
	%betad = betad + voxelModel.volumeParams(voxelType ,2); % 2 is magic number for attenuation coefficient see volumePreprocess
    betad = betad + segmentLen*voxelModel.volumeParams(voxelType ,2); % 2 is magic number for attenuation coefficient see volumePreprocess
	timeOfTravel = timeOfTravel + segmentLen / voxelModel.volumeParams(voxelType ,1); % 1 is magic number for speed coefficient see volumePreprocess
end


%if numOfVoxels
%    betad = betad/numOfVoxels;           % mean beta in [dB / cm / MHz]
%end
%FIXME units???!!!
betad = betad / 8.686 * 100 / 1e6;      % beta in [1 / Hz]
%betad = betad * len;                    % mean_beta * depth in [1 / Hz]

time = timeOfTravel;
%!rayLength = len;
%!rayLengthExpected = sqrt((startPoint(1)-endPoint(1))^2+(startPoint(2)-endPoint(2))^2+(startPoint(3)-endPoint(3))^2);
rayLength = sqrt((startPoint(1)-endPoint(1))^2+(startPoint(2)-endPoint(2))^2+(startPoint(3)-endPoint(3))^2);
%!assert( abs(rayLength - rayLengthExpected) <= 0.0001, 'Wrong length of the ray, expected %f, got %f"', rayLengthExpected, rayLength);


end 
end

