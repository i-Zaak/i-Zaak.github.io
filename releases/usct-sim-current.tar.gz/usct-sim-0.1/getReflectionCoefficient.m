function [ refCoeff ] = getReflectionCoefficient(voxelModel, pixelSize, coordReflector, modelSize)
    assert(false) % deprecated!!
    mapVoxel = ceil(coordReflector'./pixelSize); %FIXME is this correct?
    voxelType = voxelModel.voxelMatrix(mapVoxel(1), mapVoxel(2),mapVoxel(3));
    refCoeff  = voxelModel.volumeParams(voxelType ,3);
    % FIXME randomize the scattering strength
end

