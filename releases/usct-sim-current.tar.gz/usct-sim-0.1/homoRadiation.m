function [D f] = homoRadiation(a, c, theta, fs, NN)
N=round(NN/2);
n = -N:(N-1);
f = fftshift(n/N*fs);
D = ones(1,NN);