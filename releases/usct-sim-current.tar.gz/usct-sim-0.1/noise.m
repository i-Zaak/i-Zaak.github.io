clear all;
%noise values determination script
dataRoot = '/data/usct_data/exp124_breast_vnew';
resultsRoot = '/data/usct_data/noise_amplitude_stats2';
layers = 0:23;
senders = 0:95;%95;


for layer = layers
  for sender = senders
    dataFile = [dataRoot  '/layerSender_'  sprintf('%04d', layer)  '/senderNumber_'  sprintf('%04d', sender) '/data.mat'];
    resultPath = [resultsRoot '/layerSender_'  sprintf('%04d', layer)  '/senderNumber_'  sprintf('%04d', sender) ];
    mkdir(resultPath);
    resultFile = [resultPath '/stats.mat'];
    s = load( dataFile, 'AScans' );
    m = load( dataFile, 'Map');
    
    AScans = s.AScans;
    Map = m.Map;

    stats = zeros(5,size(AScans,2));
    scansSize = size(AScans,2);
    for i = 1:scansSize
      AScan = double(AScans(:,i));
      
      AScan = AScan-mean(AScan);
      noise_level = median(([std(AScan(100:200)), std(AScan(1500:1600)), std(AScan(2800:2900))]));
      amplitude = max(AScan)-min(AScan);
      stats(1:3,i) = Map(1:3,i);      
      stats(4,i) = noise_level;
      stats(5,i) = amplitude;
    end
    save(resultFile, 'stats');
  end
end









%load '/auto/smaug1.nfs4/home/izaak/usct_data/real_data_3d/exp124_breast_vnew/layerSender_0016/senderNumber_0016/' AScans
%scan = AScans(:,400)

%noise = median(([std(double(scan(1500:1600))), std(double(scan(1:100))), std(double(scan(2800:2900)))])) 
%amplitude = max(scan)-min(scan)
