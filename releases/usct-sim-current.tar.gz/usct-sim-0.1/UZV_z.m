%definovani okna s mapou
function varargout = UZV_z(varargin)

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @UZV_z_OpeningFcn, ...
                   'gui_OutputFcn',  @UZV_z_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT



% --- Executes just before UZV_z is made visible.
function UZV_z_OpeningFcn(hObject, eventdata, handles, varargin)
% Choose default command line output for UZV_z
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

h = get(0,'userdata');

Dir = get(h.edit_adr, 'String');
val = get(h.list_map,'Value');
str = get(h.list_map, 'String');
set(handles.text_namePicture,'string',str);
D = dir([Dir,'/*.bmp']);
Names = {D.name};

j = 1;
map_vel_att_name = [Dir,'/','att_vel_scat.mat'];

for nameIndex=1:length(Names)   
    imageName = char(Names(nameIndex));
    mapa = imread([Dir,'/',imageName]);
    %% vypsani urovni sedi do popup menu
    try obr2 = rgb2gray(mapa);catch end
        if exist('obr2','var');mapa = obr2;end
    [x,c] = imhist(mapa);

    for i = 1:length(x)
         if x(i)>150    % only for more than 150 pixels
            urovne(j)=c(i);
            %pocet(j)=x(i);
            j = j+1;
         end
    end
end
%FIXME duplikaty urovne a pocet
urovne = unique(urovne);
imageName = char(Names(1));
mapa = imread([Dir,'/',imageName]);
set(handles.layerLabel,'String',1);


set(handles.pmenu_show,'string',urovne);
velocity = load ('sos.txt'); %([Dir,'\',str{val},'.sos']); %('sos.txt');
vel_tab = zeros(length(velocity)+1,1);
vel_tab = [0;velocity];
set(handles.pmenu_vel,'string',velocity);
axes(handles.axes1);
imshow(mapa);
%% nacteni z externiho souboru a vypsani urovni utlumu
atten = load ('att.txt'); %([Dir,'\',str{val},'.att']); %('att.txt');
set(handles.pmenu_att,'string',atten);

%% nacteni z externiho souboru a vypsani echogenity
atten = load ('echo.txt'); %([Dir,'\',str{val},'.echo']); %('echo.txt');
set(handles.pmenu_echo,'string',atten);

%%  osetreni obrazku ohledne pozadovanych urovni
mapa = double(mapa);
for i = 1:length(urovne)-1
    mapa((mapa>=urovne(i))&(mapa<urovne(i+1)))=urovne(i);
end
%% zjisteni zdali existuje mapa rychlosti
try map_vel_att = load (map_vel_att_name);catch end

if exist ('map_vel_att')
    map_vel = map_vel_att.map_vel;
    map_att = map_vel_att.map_att;
    map_echo = map_vel_att.map_echo;

    map_mat = get(handles.pmenu_show,'string');map_mat = str2num(map_mat);
    set(handles.text_mat,'string',map_mat);

    saveVel = get(handles.pmenu_vel,'string');saveVel = str2num(saveVel);
    set(handles.text_vel,'string',map_vel);

    saveAtt = get(handles.pmenu_att,'string');saveAtt = str2num(saveAtt);
    set(handles.text_att,'string',map_att);

    saveEcho = get(handles.pmenu_echo,'string');saveEcho = str2num(saveEcho);
    set(handles.textecho,'string',map_echo);
end

%%
% UIWAIT makes UZV_z wait for user response (see UIRESUME)
% --- Outputs from this function are returned to the command line.
function varargout = UZV_z_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function axes(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes1


% --- Executes on selection change in pmenu_vel.
function pmenu_vel_Callback(hObject, eventdata, handles)
% hObject    handle to pmenu_vel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns pmenu_vel contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pmenu_vel


% --- Executes during object creation, after setting all properties.
function pmenu_vel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pmenu_vel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btn_save.
% "Save Tissue Properties"
function btn_save_Callback(hObject, eventdata, handles)
% hObject    handle to btn_save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

saveMatNum = get (handles.pmenu_show,'value');
map_mat = get(handles.pmenu_show,'string');map_mat = str2num(map_mat);
saveVelNum = get(handles.pmenu_vel,'value');
saveVel = get(handles.pmenu_vel,'string');saveVel = str2num(saveVel);
saveAttNum = get(handles.pmenu_att,'value');
saveAtt = get(handles.pmenu_att,'string');saveAtt = str2num(saveAtt);
saveEchoNum = get(handles.pmenu_echo,'value');
saveEcho = get(handles.pmenu_echo,'string');saveEcho = str2num(saveEcho);

h = get(0,'userdata');
Dir = get(h.edit_adr, 'String');
val = get(h.list_map,'Value');
str = get(h.list_map, 'String');
%FIXME map_vel_att_name = [Dir,'\',str{val},'.att_vel_scat.mat'];
map_vel_att_name = [Dir,'/','att_vel_scat.mat'];

try map_vel_att = load (map_vel_att_name);catch end

if exist ('map_vel_att')
    map_vel = map_vel_att.map_vel;
    map_att = map_vel_att.map_att;
    map_echo = map_vel_att.map_echo;
else
    map_vel = zeros(length(map_mat),1);
    map_att = zeros(length(map_mat),1);
    map_echo = zeros(length(map_mat),1);
end

map_vel(saveMatNum,1)= saveVel(saveVelNum);
map_att(saveMatNum,1)= saveAtt(saveAttNum);
map_echo(saveMatNum,1)= saveEcho(saveEchoNum);

set(handles.text_mat,'string',map_mat);
set(handles.text_vel,'string',map_vel);
set(handles.text_att,'string',map_att);
set(handles.textecho,'string',map_echo);

save(map_vel_att_name,'-double','map_vel','map_mat','map_att','map_echo');


% --- Executes on button press in btn_close.
% "Save and Close"
function btn_close_Callback(hObject, eventdata, handles)
% hObject    handle to btn_close (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%% Save first:
btn_save_Callback(hObject, eventdata, handles);

%% osetreni zadani vsech pozadovanych rychlosti
h = get(0,'userdata');
Dir = get(h.edit_adr, 'String');
val = get(h.list_map,'Value');
str = get(h.list_map, 'String');
%FIXME map_vel_att_name = [Dir,'\',str{val},'.att_vel_scat.mat'];
map_vel_att_name = [Dir,'/','att_vel_scat.mat'];

try obr = load (map_vel_att_name);   
mapa = obr.map_vel;catch end

if exist ('mapa')
    if min(min(mapa))< 10
      button = questdlg('Tissue parameters not complete. Really quit?','Warning');
        switch button
            case 'Yes'
                try delete(UZV_z);catch end
        end
    else
        try delete(UZV_z);catch end
    end
else
    button = questdlg('Tissue parameters not complete. Really quit?','Warning');
        switch button
            case 'Yes'
                try delete(UZV_z);catch end
        end
end


% --- Executes on button press in btn_show.
% "Show Selected Tissue"
function btn_show_Callback(hObject, eventdata, handles)
% hObject    handle to btn_show (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% inicializace
h = get(0,'userdata');

Dir = get(h.edit_adr, 'String');
val = get(h.list_map,'Value');
str = get(h.list_map, 'String');
%mapa = imread([Dir,'\',str{val}]);

D = dir([Dir,'/*.bmp']);
Names = {D.name};
nameIndex = str2num(get(handles.layerLabel, 'String'));
imageName = char(Names(nameIndex));
mapa = imread([Dir,'/',imageName]);


%%  vytvoreni matice s cervenou barvou
map_colour=0:255;
map_colour=repmat(map_colour',1,3);
map_colour=map_colour/255;
map_colour = [map_colour; 1 0 0];
mapa_red = uint16(mapa);

%% vyber odstinu sedi a zobrazeni
vyber = get(handles.pmenu_show,'value');
ret = get (handles.pmenu_show,'string');
ret2=str2num(ret);
mapa_red(mapa_red==ret2(vyber))=256;
axes(handles.axes1);
imshow(mapa_red,map_colour)

% --- Executes on selection change in pmenu_vel_show.
function pmenu_show_Callback(hObject, eventdata, handles)
% hObject    handle to pmenu_vel_show (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns pmenu_vel_show contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pmenu_vel_show

		

% --- Executes during object creation, after setting all properties.
function pmenu_show_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pmenu_vel_show (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes during object creation, after setting all properties.
function text_mat_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text_mat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called




% --- Executes on selection change in pmenu_att.
function pmenu_att_Callback(hObject, eventdata, handles)
% hObject    handle to pmenu_att (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns pmenu_att contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pmenu_att


% --- Executes during object creation, after setting all properties.
function pmenu_att_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pmenu_att (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes on selection change in pmenu_echo.
function pmenu_echo_Callback(hObject, eventdata, handles)
% hObject    handle to pmenu_echo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns pmenu_echo contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pmenu_echo


% --- Executes during object creation, after setting all properties.
function pmenu_echo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pmenu_echo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes on button press in prev_btn.
function prev_btn_Callback(hObject, eventdata, handles)
% hObject    handle to prev_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
h = get(0,'userdata');

Dir = get(h.edit_adr, 'String');

D = dir([Dir,'/*.bmp']);
Names = {D.name};
nameIndex = str2num(get(handles.layerLabel, 'String'));
if( nameIndex > 1)
    nameIndex = nameIndex - 1; 
end
imageName = char(Names(nameIndex));
mapa = imread([Dir,'/',imageName]);
set(handles.layerLabel, 'String', nameIndex);
axes(handles.axes1);
imshow(mapa);

% --- Executes on button press in next_btn.
function next_btn_Callback(hObject, eventdata, handles)
% hObject    handle to next_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
h = get(0,'userdata');

Dir = get(h.edit_adr, 'String');

D = dir([Dir,'/*.bmp']);
Names = {D.name};
nameIndex = str2num(get(handles.layerLabel, 'String'));
if( nameIndex < length(Names))
    nameIndex = nameIndex + 1; 
end
imageName = char(Names(nameIndex));
mapa = imread([Dir,'/',imageName]);
set(handles.layerLabel, 'String', nameIndex);
axes(handles.axes1);
imshow(mapa);
