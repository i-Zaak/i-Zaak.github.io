X = SX; Z = SZ;     %prirazeni velikosti obrazku

x1 = 0;
x2 = len_xy;

mmm = min([z1 z2]);
z1 = z1 - mmm;
z2 = z2 - mmm;

len_z = abs(z1-z2);

% line coefficients:
aa1 = (z1-z2)/(x1-x2);  %
bb1 = z1 - aa1*x1;      %rovnice primky

% ix1 = round(x1*X/len_xy + X/2 + 0.5);
% ix2 = round(x2*X/len_xy + X/2 + 0.5);
% iz1 = round(z1*Z/abs(z1-z2) + Z/2 + 0.5);
% iz2 = round(z2*Z/abs(z1-z2) + Z/2 + 0.5);
ix1 = 1; %round(x1*X/len_xy);
ix2 = X; %round(x2*X/len_xy);
% mmm = min([ix1 ix2]);
% ix1 = ix1 - mmm + 1;
% ix2 = ix2 - mmm + 1;

iz1 = round(z1*Z/ len_z + 0.5);
iz2 = round(z2*Z/ len_z + 0.5);


% count
count = 0;
betad = 0;
tcel = 0;

if (abs(aa1)<1)     %urceni sklonu primky..jake koeficienty se budou pocitat
	mi = min(ix1,ix2);
	MA = max(ix1,ix2);
	for iix = mi:MA;
		x = (iix-0.5)*len_xy/X;
		z = aa1*x + bb1;
		iiz = round(z*Z/len_z + 0.5);
       
        if ((iiz>0)&&(iiz<=Z)&&(iix<=X)&&(iix>0))
            betad = betad + resultB_xy(iiz,iix); 
			count = count + 1;
        end
         
        if ((iiz>0)&&(iiz<=Z)&&(iix<=X)&&(iix>0))
            spix = len/(MA-mi+1);
            tpix = spix/resultV_xy(iiz,iix);
            tcel = tcel + tpix;
        end      
        
        
    end
else
	mi = min(iz1,iz2);
	MA = max(iz1,iz2);
	for iiz = mi:MA
		z = (iiz-0.5)*len_z/Z;
		x = (z - bb1)/aa1;
		iix = round(x*X/len_xy + 0.5);
		   
        if ((iix>0)&&(iix<=X)&&(iiz<=Z)&&(iiz>0))
			betad = betad + resultB_xy(iiz,iix);
			count = count + 1;
		end
        
        if ((iix>0)&&(iix<=X)&&(iiz<=Z)&&(iiz>0))
            spix = len/(MA-mi+1);
            tpix = spix/resultV_xy(iiz,iix);
            tcel = tcel + tpix;
        end
        
	end
end

if count
	betad = betad / count;           % mean beta in [dB / cm / MHz]
end
betad = betad / 8.686 * 100 / 1e6;     % mean beta in [1 / m / Hz]
betad = betad * len;             % mean_beta * depth in [1 / Hz]