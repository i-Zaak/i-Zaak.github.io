function [ P N_spect ] = kruhePulse(fs,f0)
assert(fs == 10e6);
%load /data/usct_data/3d/exp150_EmpyMeasurment_TempLog/layerSender_0000/senderNumber_0000/data;
load /mnt/data/izaak/usct_real_data/exp150_EmpyMeasurment_TempLog/layerSender_0000/senderNumber_0000/data;

% sender layer 0
% sender no. 0
% rec. layer 0 ... Map(1,:)=0;
% rec. no. 192/2=96 ...Map(2,:)=96
scan_index =  find(Map(1,:)==0 & Map(2,:)==96);

%Map(:,scan_index)
% zatim nahrubo podle prumeru, melo by byt presneji podle souradnic vysilace a prijimace
radius = 0.18407 / 2; %[m]
c = 1490; % [m/s]
Ts = 1/10e6; %[s]
index =  radius*2 / c / Ts;   % index zacatku pulsu

plot(AScans(:,scan_index))  % cely AScan
pause

puls = double( AScans(round(index):round(index)+127,scan_index)' );
puls = puls - mean(puls);

plot(puls)  % puls vyriznuty
pause

N_spect = 2*length(puls);
%theta = 20;
%fs = 10e6;
%a = sqrt(1.4e-6/pi);

P = fft(puls,N_spect);
P(128-20:128+20:end) = 0;


%[D1,f] = directivity(a, c, theta, fs, N);
%D2 = D1;


%figure(1)
%  plot(abs(D1))
%pause
% plot(angle(D1))
%  konecny_puls = real(ifft(PULS .* D1 .* D2));

%pause
%plot(konecny_puls);
end

